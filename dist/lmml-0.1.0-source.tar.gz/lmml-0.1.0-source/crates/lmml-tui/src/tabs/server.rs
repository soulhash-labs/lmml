//! Server tab rendering.

use ratatui::layout::Rect;
use ratatui::text::Line;
use ratatui::Frame;

use crate::app::{App, ServerStatus};

/// Render the server tab.
pub fn render(area: Rect, app: &App, frame: &mut Frame) {
    let action = match app.server_status {
        ServerStatus::Stopped | ServerStatus::Failed { .. } => "Press s to start server.",
        ServerStatus::Starting { .. } | ServerStatus::Ready { .. } => "Press s to stop server.",
    };
    let runtime_policy = format!(
        "Press v: engine auto/upstream/prism (now {}).",
        app.state.build.runtime_selection
    );
    let selected_model = app.selected_server_model();
    let displayed_model = app
        .active_server_model
        .as_ref()
        .cloned()
        .or_else(|| selected_model.clone());
    let model = displayed_model
        .as_ref()
        .map(|model| model.path.display().to_string())
        .unwrap_or_else(|| "No model selected".to_string());
    let profile = displayed_model
        .as_ref()
        .and_then(|model| {
            app.state
                .model
                .runtime_profile_for_path(&model.path)
                .map(|profile| profile.name.clone())
        })
        .unwrap_or_else(|| "custom/global".to_string());
    let gpu_layers = app.server_gpu_layers_label(selected_model.as_ref());
    let runtime_flavor = app.active_runtime_flavor.or_else(|| {
        displayed_model
            .as_ref()
            .and_then(|model| model.runtime.flavor())
    });
    let runtime_binary = app
        .active_runtime_binary
        .as_deref()
        .or_else(|| runtime_flavor.map(|flavor| app.state.build.runtime_binary(flavor)))
        .unwrap_or(&app.state.build.binary);
    let runtime_commit = runtime_flavor
        .map(|flavor| app.state.build.runtime_commit(flavor))
        .filter(|commit| !commit.is_empty())
        .unwrap_or("unknown");
    let left = vec![
        Line::from(action),
        Line::from(runtime_policy),
        Line::from("Press p to switch the selected model's runtime profile."),
        Line::from(format!("Status: {:?}", app.server_status)),
        Line::from(format!("Profile: {profile}")),
        Line::from(format!(
            "{}: {model}",
            if app.active_server_model.is_some() {
                "Last ready model"
            } else {
                "Selected model"
            }
        )),
        Line::from(format!(
            "Runtime: {}",
            runtime_flavor
                .map(|flavor| flavor.to_string())
                .unwrap_or_else(|| "not resolved".to_string())
        )),
        Line::from(format!("Runtime commit: {runtime_commit}")),
        Line::from(format!("Binary: {}", runtime_binary.display())),
        Line::from(format!("Host: {}", app.state.server.host)),
        Line::from(format!("Port: {}", app.state.server.port)),
        Line::from(format!("Context: {}", app.state.server.ctx_size)),
        Line::from(format!("GPU layers: {gpu_layers}")),
        Line::from(format!("Batch: {}", app.state.server.batch_size)),
        Line::from(format!("Threads: {}", app.state.server.threads)),
    ];
    let right = if app.server_log.is_empty() {
        vec![Line::from("Server log will appear here.")]
    } else {
        app.server_log.iter().cloned().map(Line::from).collect()
    };
    super::render_two_pane(
        area,
        super::pane("Server", left),
        super::pane("Server Log", right),
        frame,
    );
}
