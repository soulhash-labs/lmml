//! Application state and action dispatch for the TUI.
//!
//! Rendering lives in `tabs` and widgets. This module owns navigation, modal
//! state, background-task status, and persistent state coordination.

mod settings_state;

use crossterm::event::{KeyCode, KeyEvent, KeyModifiers};
use std::path::{Path, PathBuf};

use lmml_build::{BuildEvent, UpdateCheck};
use lmml_compat::LlamaBinaryCapabilities;
use lmml_detect::{BuildBackend, SystemProfile};
use lmml_models::{DownloadProgress, HfModelResult, HfSearchQuery, ModelEntry, QuantTier, VramFit};
use lmml_server::ServerHandle;
pub use lmml_server::ServerStatus;
use lmml_state::AppState as PersistentState;

use crate::action::Action;
pub use settings_state::{SettingsField, SettingsKeyResult};

/// Top-level TUI tabs.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Tab {
    /// Hardware detection tab.
    Detect,
    /// llama.cpp build tab.
    Build,
    /// Local/HF models tab.
    Models,
    /// llama-server lifecycle tab.
    Server,
    /// Settings editor tab.
    Settings,
}

impl Tab {
    /// All tabs in display order.
    pub const ALL: [Tab; 5] = [
        Tab::Detect,
        Tab::Build,
        Tab::Models,
        Tab::Server,
        Tab::Settings,
    ];

    /// User-visible tab title.
    pub fn title(self) -> &'static str {
        match self {
            Tab::Detect => "Detect",
            Tab::Build => "Build",
            Tab::Models => "Models",
            Tab::Server => "Server",
            Tab::Settings => "Settings",
        }
    }

    fn index(self) -> usize {
        Self::ALL
            .iter()
            .position(|tab| *tab == self)
            .unwrap_or_default()
    }
}

/// Background and terminal events consumed by the app.
#[derive(Debug, Clone)]
pub enum AppEvent {
    /// Terminal key press.
    Key(KeyEvent),
    /// Terminal resize.
    Resize(u16, u16),
    /// Detection task completed.
    DetectComplete(Box<SystemProfile>),
    /// Build task emitted an event.
    BuildEvent(BuildEvent),
    /// Server status changed.
    ServerStatus(ServerStatus),
    /// Server startup completed.
    ServerStarted(Result<ServerHandle, String>),
    /// Server model-swap restart completed.
    ServerModelSwapComplete {
        /// Model requested for the replacement server.
        model: ModelEntry,
        /// Restart result.
        result: Result<ServerHandle, String>,
    },
    /// llama-server capabilities probe completed.
    ServerCapabilities(Result<LlamaBinaryCapabilities, String>),
    /// Server log line.
    ServerLog(String),
    /// Download progress changed.
    DownloadProgress(DownloadProgress),
    /// Download completed.
    DownloadComplete(Result<ModelEntry, String>),
    /// Model scan completed.
    ModelScanComplete(Vec<ModelEntry>),
    /// Model registry mutation failed.
    ModelRegistryError(String),
    /// Hugging Face search completed.
    HfSearchResults(Vec<HfModelResult>),
    /// Update check completed.
    UpdateCheckResult(UpdateCheck),
}

/// Active user-input modal.
#[derive(Debug, Clone, PartialEq, Eq)]
pub enum Modal {
    /// Path prompt for adding an external model alias.
    AddAlias {
        /// Current path input buffer.
        buffer: String,
        /// Inline validation error.
        error: Option<String>,
    },
    /// Confirmation prompt for deleting a model.
    ConfirmDelete {
        /// Model selected for deletion.
        model: ModelEntry,
    },
    /// Confirmation prompt for restarting server with another model.
    ConfirmModelSwap {
        /// Model selected for serving after restart.
        model: ModelEntry,
    },
    /// Hugging Face search query editor.
    HfSearch {
        /// Focused search field.
        field: HfSearchField,
        /// Keyword query buffer.
        keywords: String,
        /// Optional architecture filter buffer.
        architecture: String,
        /// Optional quantization tier filter.
        quant_filter: Option<QuantTier>,
        /// Inline validation error.
        error: Option<String>,
    },
}

/// Editable fields in the Hugging Face search modal.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum HfSearchField {
    /// Keyword query.
    Keywords,
    /// Architecture filter.
    Architecture,
    /// Quantization tier filter.
    Quant,
}

/// First-run onboarding step.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OnboardingStep {
    /// Prompt to scan the system.
    Scan,
    /// Hardware summary after detection.
    HardwareSummary,
    /// Confirm or choose backend.
    Backend,
    /// Choose model directory.
    ModelsDir,
    /// Optional starter-model search/download.
    StarterModel,
    /// Configure server port.
    ServerPort,
    /// Final completion screen.
    Done,
}

/// Mutable application state owned by the event loop.
#[derive(Debug)]
pub struct App {
    /// Persisted state loaded from `lmml-state`.
    pub state: PersistentState,
    /// Active top-level tab.
    pub active_tab: Tab,
    /// Whether the application should quit.
    pub should_quit: bool,
    /// Whether the help overlay is visible.
    pub show_help: bool,
    /// Whether first-run onboarding should be shown.
    pub first_run_onboarding: bool,
    /// Current first-run onboarding step.
    pub onboarding_step: OnboardingStep,
    /// Backend selected during onboarding.
    pub onboarding_backend: Option<BuildBackend>,
    /// Model directory input buffer for onboarding.
    pub onboarding_models_dir_buffer: String,
    /// Server port input buffer for onboarding.
    pub onboarding_port_buffer: String,
    /// Inline onboarding validation error.
    pub onboarding_error: Option<String>,
    /// Full detection profile for the current session.
    pub detect_profile: Option<SystemProfile>,
    /// Whether hardware detection is currently running.
    pub detect_running: bool,
    /// Current server status.
    pub server_status: ServerStatus,
    /// Last probed llama-server capabilities.
    pub server_caps: Option<LlamaBinaryCapabilities>,
    /// Last server capability probe error.
    pub server_caps_error: Option<String>,
    /// Model used by the last server that reached ready state.
    pub active_server_model: Option<ModelEntry>,
    /// Runtime flavor used by the last server that reached ready state.
    pub active_runtime_flavor: Option<lmml_compat::LlamaRuntimeFlavor>,
    /// Exact binary used by the last server that reached ready state.
    pub active_runtime_binary: Option<PathBuf>,
    pending_server_model: Option<ModelEntry>,
    pending_runtime_flavor: Option<lmml_compat::LlamaRuntimeFlavor>,
    pending_runtime_binary: Option<PathBuf>,
    /// Detect tab log lines.
    pub detect_log: Vec<String>,
    /// Build tab log lines.
    pub build_log: Vec<String>,
    /// Whether a build is currently running.
    pub build_running: bool,
    active_build_flavor: Option<lmml_compat::LlamaRuntimeFlavor>,
    /// Last completed build binary, if any.
    pub build_binary: Option<PathBuf>,
    /// Last build error, if any.
    pub build_error: Option<String>,
    /// Server tab log lines.
    pub server_log: Vec<String>,
    /// Models found by the registry scan.
    pub models: Vec<ModelEntry>,
    /// Whether a model directory scan is currently running.
    pub model_scan_running: bool,
    /// Selected model list index.
    pub selected_model: usize,
    /// Whether HF search pane is open.
    pub hf_search_open: bool,
    /// Current HF search query.
    pub hf_query: String,
    /// HF search results.
    pub hf_results: Vec<HfModelResult>,
    /// Selected HF result index.
    pub selected_hf_result: usize,
    /// Current download progress.
    pub download_progress: Option<DownloadProgress>,
    /// Last download error.
    pub download_error: Option<String>,
    /// Last update-check result.
    pub update_check: Option<UpdateCheck>,
    /// Selected Settings tab field.
    pub selected_settings_field: SettingsField,
    /// Active inline settings edit buffer.
    pub settings_edit_buffer: Option<String>,
    /// Inline validation error for the Settings tab.
    pub settings_validation_error: Option<String>,
    /// Active modal prompt.
    pub active_modal: Option<Modal>,
    /// Optional state path override used by integration-style tests.
    pub state_save_path: Option<PathBuf>,
    /// Last UI status message.
    pub status_message: String,
    /// Current terminal size.
    pub terminal_size: Option<(u16, u16)>,
}

impl App {
    /// Construct an app using state loaded from disk, falling back to defaults on error.
    pub fn new() -> Self {
        let first_run = !PersistentState::path().exists();
        let state = PersistentState::load().unwrap_or_default();
        Self::new_with_state_and_first_run(state, first_run)
    }

    /// Construct an app with injected state for tests.
    pub fn new_with_state(state: PersistentState) -> Self {
        Self::new_with_state_and_first_run(state, false)
    }

    /// Construct an app with injected state and onboarding flag for tests.
    pub fn new_with_state_and_first_run(
        mut state: PersistentState,
        first_run_onboarding: bool,
    ) -> Self {
        state.model.ensure_builtin_profiles();
        if let Some(profile) = state
            .model
            .runtime_profile_for_path(&state.model.last_used)
            .cloned()
        {
            state.model.active_profile = profile.name;
            state.server = profile.server;
        }
        let onboarding_models_dir_buffer = state.model.models_dir.to_string_lossy().into_owned();
        let onboarding_port_buffer = state.server.port.to_string();
        Self {
            state,
            active_tab: Tab::Detect,
            should_quit: false,
            show_help: false,
            first_run_onboarding,
            onboarding_step: OnboardingStep::Scan,
            onboarding_backend: None,
            onboarding_models_dir_buffer,
            onboarding_port_buffer,
            onboarding_error: None,
            detect_profile: None,
            detect_running: false,
            server_status: ServerStatus::Stopped,
            server_caps: None,
            server_caps_error: None,
            active_server_model: None,
            active_runtime_flavor: None,
            active_runtime_binary: None,
            pending_server_model: None,
            pending_runtime_flavor: None,
            pending_runtime_binary: None,
            detect_log: Vec::new(),
            build_log: Vec::new(),
            build_running: false,
            active_build_flavor: None,
            build_binary: None,
            build_error: None,
            server_log: Vec::new(),
            models: Vec::new(),
            model_scan_running: false,
            selected_model: 0,
            hf_search_open: false,
            hf_query: "gguf".to_string(),
            hf_results: Vec::new(),
            selected_hf_result: 0,
            download_progress: None,
            download_error: None,
            update_check: None,
            selected_settings_field: SettingsField::Host,
            settings_edit_buffer: None,
            settings_validation_error: None,
            active_modal: None,
            state_save_path: None,
            status_message: "Ready".to_string(),
            terminal_size: None,
        }
    }

    /// Handle a terminal/background event.
    pub fn handle_event(&mut self, event: AppEvent) -> Option<Action> {
        match event {
            AppEvent::Key(key) => self.handle_key(key),
            AppEvent::Resize(width, height) => {
                self.terminal_size = Some((width, height));
                None
            }
            AppEvent::DetectComplete(profile) => {
                self.detect_running = false;
                let profile = *profile;
                self.state.system_profile = Some(lmml_state::SystemProfile {
                    cuda_toolkit: match &profile.cuda {
                        lmml_detect::CudaCompatibility::Compatible { .. } => {
                            Some("available".to_string())
                        }
                        lmml_detect::CudaCompatibility::ToolkitTooOld { found_toolkit, .. }
                        | lmml_detect::CudaCompatibility::ToolkitTooNew { found_toolkit, .. } => {
                            Some(found_toolkit.clone())
                        }
                        lmml_detect::CudaCompatibility::NoGpu
                        | lmml_detect::CudaCompatibility::NvccMissing => None,
                    },
                    gpu_names: detected_gpu_names(&profile),
                    gpu_archs: profile
                        .gpus
                        .iter()
                        .filter_map(|gpu| gpu.arch.map(ToOwned::to_owned))
                        .collect(),
                    rocm_available: profile.rocm.available,
                    rocm_targets: profile.rocm.targets.clone(),
                    vram_mb: detected_vram_mb(&profile),
                    sccache: profile.sccache.is_some(),
                });
                self.sync_build_backend_after_detection(&profile);
                self.detect_log.push(format!(
                    "Detected backend: {:?}",
                    profile.recommended_backend()
                ));
                for warning in profile.warnings() {
                    self.detect_log
                        .push(format!("Warning: {}", warning.message));
                }
                for missing in profile.missing_prerequisites() {
                    self.detect_log
                        .push(format!("Missing {}: {}", missing.name, missing.install));
                }
                self.detect_profile = Some(profile);
                if self.first_run_onboarding {
                    self.onboarding_step = OnboardingStep::HardwareSummary;
                    self.onboarding_backend = self
                        .detect_profile
                        .as_ref()
                        .map(SystemProfile::recommended_backend);
                }
                self.status_message = "Detection complete".to_string();
                self.save_state_after("Detection complete");
                None
            }
            AppEvent::BuildEvent(event) => {
                self.handle_build_event(event);
                None
            }
            AppEvent::ServerStatus(status) => {
                self.server_status = status;
                None
            }
            AppEvent::ServerStarted(result) => {
                match result {
                    Ok(handle) => {
                        self.server_status = handle.status();
                        self.commit_pending_server();
                        self.status_message = "Server ready".to_string();
                    }
                    Err(error) => {
                        self.clear_pending_server();
                        self.server_status = ServerStatus::Failed {
                            reason: error.clone(),
                        };
                        self.status_message = format!("Server failed: {error}");
                    }
                }
                None
            }
            AppEvent::ServerModelSwapComplete { model, result } => {
                match result {
                    Ok(handle) => {
                        self.server_status = handle.status();
                        self.commit_pending_server();
                        self.select_model_path(model.path.clone());
                        if let Some(index) = self
                            .models
                            .iter()
                            .position(|entry| entry.path == model.path)
                        {
                            self.selected_model = index;
                        }
                        self.status_message = format!("Server restarted with {}", model.name);
                        self.save_state_after("Model selected");
                    }
                    Err(error) => {
                        self.clear_pending_server();
                        self.server_status = ServerStatus::Failed {
                            reason: error.clone(),
                        };
                        self.status_message = format!("Model swap failed: {error}");
                    }
                }
                None
            }
            AppEvent::ServerCapabilities(result) => {
                match result {
                    Ok(caps) => {
                        self.server_caps = Some(caps);
                        self.server_caps_error = None;
                        self.status_message = "Server capabilities probed".to_string();
                    }
                    Err(error) => {
                        self.server_caps = None;
                        self.server_caps_error = Some(error.clone());
                        self.status_message = format!("Capability probe failed: {error}");
                    }
                }
                None
            }
            AppEvent::ServerLog(line) => {
                self.server_log.push(line);
                const MAX_SERVER_LOG_LINES: usize = 500;
                if self.server_log.len() > MAX_SERVER_LOG_LINES {
                    let overflow = self.server_log.len() - MAX_SERVER_LOG_LINES;
                    self.server_log.drain(0..overflow);
                }
                None
            }
            AppEvent::DownloadProgress(progress) => {
                self.download_progress = Some(progress.clone());
                self.status_message = match progress.total_bytes {
                    Some(total) => {
                        format!("Downloading {} / {} bytes", progress.bytes_received, total)
                    }
                    None => format!("Downloading {} bytes", progress.bytes_received),
                };
                None
            }
            AppEvent::DownloadComplete(result) => {
                match result {
                    Ok(model) => {
                        self.download_error = None;
                        self.status_message = format!("Downloaded {}", model.name);
                        self.select_model_path(model.path.clone());
                        self.models.push(model);
                        self.save_state_after("Model downloaded");
                    }
                    Err(error) => {
                        self.download_error = Some(error.clone());
                        self.status_message = format!("Download failed: {error}");
                    }
                }
                None
            }
            AppEvent::ModelScanComplete(models) => {
                self.model_scan_running = false;
                let count = models.len();
                self.models = models;
                self.selected_model = self.selected_model.min(self.models.len().saturating_sub(1));
                self.status_message = format!("{count} model(s) found");
                None
            }
            AppEvent::ModelRegistryError(error) => {
                self.status_message = error;
                None
            }
            AppEvent::HfSearchResults(results) => {
                let count = results.len();
                self.hf_results = results;
                self.selected_hf_result = self
                    .selected_hf_result
                    .min(self.hf_results.len().saturating_sub(1));
                self.status_message = format!("{count} Hugging Face result(s)");
                None
            }
            AppEvent::UpdateCheckResult(update) => {
                self.update_check = Some(update);
                None
            }
        }
    }

    /// Dispatch a user action into local state changes.
    pub fn dispatch(&mut self, action: Action) {
        match action {
            Action::RunDetect => {
                self.detect_running = true;
                self.detect_log
                    .push("Starting system detection".to_string());
                self.status_message = "Detecting system".to_string();
            }
            Action::StartBuild => {
                self.invalidate_selected_prism_build("Prism build requested");
                self.first_run_onboarding = false;
                self.build_running = true;
                self.build_error = None;
                self.push_build_log("Starting build");
                self.status_message = "Build requested".to_string();
            }
            Action::CleanBuild => {
                self.invalidate_selected_prism_build("Prism clean build requested");
                self.first_run_onboarding = false;
                self.build_running = true;
                self.build_error = None;
                self.push_build_log("Starting clean build");
                self.status_message = "Clean build requested".to_string();
            }
            Action::CancelBuild => {
                self.push_build_log("Build cancellation requested");
                self.status_message = "Cancelling build".to_string();
            }
            Action::StartServer => {
                self.server_status = ServerStatus::Starting {
                    elapsed: std::time::Duration::ZERO,
                };
                self.status_message = "Starting server".to_string();
            }
            Action::StopServer => {
                self.server_status = ServerStatus::Stopped;
                self.status_message = "Server stopped".to_string();
            }
            Action::ProbeServerCapabilities => {
                self.status_message = "Probing server capabilities".to_string();
            }
            Action::SelectModel(path) => {
                let applied_profile = self.select_model_path(path);
                self.status_message = "Model selected".to_string();
                if applied_profile {
                    self.status_message = "Model selected; runtime profile applied".to_string();
                }
                self.save_state_after("Model selected");
            }
            Action::CycleRuntimeProfile(path) => {
                let running = matches!(
                    self.server_status,
                    ServerStatus::Starting { .. } | ServerStatus::Ready { .. }
                );
                if let Some(profile) = self
                    .state
                    .model
                    .cycle_runtime_profile_for_path(&path)
                    .cloned()
                {
                    self.state.server = resolved_profile_server(&path, &profile);
                    self.status_message = if running {
                        format!("Profile {}; restart server to apply", profile.name)
                    } else {
                        format!("Profile {} applied", profile.name)
                    };
                    self.save_state_after("Runtime profile selected");
                } else {
                    self.status_message = "No runtime profiles for selected model".to_string();
                }
            }
            Action::CycleRuntimeSelection => {
                self.state.build.runtime_selection = match self.state.build.runtime_selection {
                    lmml_state::RuntimeSelectionMode::Auto => {
                        lmml_state::RuntimeSelectionMode::Upstream
                    }
                    lmml_state::RuntimeSelectionMode::Upstream => {
                        lmml_state::RuntimeSelectionMode::Prism
                    }
                    lmml_state::RuntimeSelectionMode::Prism => {
                        lmml_state::RuntimeSelectionMode::Auto
                    }
                };
                self.status_message =
                    format!("Runtime policy: {}", self.state.build.runtime_selection);
                self.save_state_after("Runtime policy selected");
            }
            Action::ScanModels => {
                self.model_scan_running = true;
                self.status_message = "Scanning models".to_string();
            }
            Action::OpenHfSearch => {
                self.hf_search_open = true;
                self.active_modal = Some(Modal::HfSearch {
                    field: HfSearchField::Keywords,
                    keywords: self.hf_query.clone(),
                    architecture: String::new(),
                    quant_filter: None,
                    error: None,
                });
                self.status_message = "HF search opened".to_string();
            }
            Action::SearchHf(query) => {
                self.hf_search_open = true;
                self.hf_query = query.keywords.clone();
                self.active_modal = None;
                self.status_message = format!("Searching: {}", query.keywords);
            }
            Action::DownloadModel(result) => {
                self.download_progress = None;
                self.download_error = None;
                self.status_message = format!("Downloading {}", result.filename);
            }
            Action::DeleteModel(model) => {
                self.active_modal = Some(Modal::ConfirmDelete { model });
                self.status_message = "Confirm model delete".to_string();
            }
            Action::ConfirmDeleteModel(model) => {
                self.active_modal = None;
                self.status_message = format!("Deleting {}", model.name);
            }
            Action::ConfirmModelSwap(model) => {
                self.active_modal = None;
                self.status_message = format!("Restarting server with {}", model.name);
            }
            Action::AddModelAlias => {
                self.active_modal = Some(Modal::AddAlias {
                    buffer: String::new(),
                    error: None,
                });
                self.status_message = "Enter model alias path".to_string();
            }
            Action::ConfirmAddModelAlias(path) => {
                self.active_modal = None;
                self.status_message = format!("Adding alias {}", path.display());
            }
            Action::CheckForUpdate => {
                self.status_message = "Checking for updates".to_string();
            }
            Action::UpdateAndRebuild => {
                self.invalidate_selected_prism_build("Prism update requested");
                self.first_run_onboarding = false;
                self.build_running = true;
                self.build_error = None;
                self.push_build_log("Updating source and starting clean rebuild");
                self.status_message = match self.state.build.track_mode {
                    lmml_state::TrackMode::Main => "Updating main and rebuilding".to_string(),
                    lmml_state::TrackMode::Tag => "Rebuilding pinned ref".to_string(),
                };
            }
            Action::SaveSettings => {
                self.status_message = if self.state.save().is_ok() {
                    "Settings saved".to_string()
                } else {
                    "Settings save failed".to_string()
                };
            }
            Action::ShowHelp => {
                self.show_help = !self.show_help;
                if self.first_run_onboarding {
                    self.first_run_onboarding = false;
                }
            }
            Action::Quit => {
                self.save_state_after("State saved");
                self.should_quit = true;
            }
        }
    }

    fn handle_key(&mut self, key: KeyEvent) -> Option<Action> {
        if key.modifiers.contains(KeyModifiers::CONTROL) && key.code == KeyCode::Char('c') {
            return Some(Action::Quit);
        }
        if self.active_modal.is_some() {
            return self.handle_modal_key(key);
        }
        if self.first_run_onboarding {
            return self.handle_onboarding_key(key);
        }
        if self.active_tab == Tab::Settings {
            match self.handle_settings_key(key) {
                SettingsKeyResult::Handled(action) => return *action,
                SettingsKeyResult::Unhandled => {}
            }
        }

        match key.code {
            KeyCode::Char('1') => {
                self.active_tab = Tab::Detect;
                None
            }
            KeyCode::Char('2') => {
                self.active_tab = Tab::Build;
                None
            }
            KeyCode::Char('3') => {
                self.active_tab = Tab::Models;
                None
            }
            KeyCode::Up if self.active_tab == Tab::Models => {
                if self.hf_search_open && !self.hf_results.is_empty() {
                    self.selected_hf_result = self.selected_hf_result.saturating_sub(1);
                } else {
                    self.select_previous_model();
                }
                None
            }
            KeyCode::Down if self.active_tab == Tab::Models => {
                if self.hf_search_open && !self.hf_results.is_empty() {
                    self.selected_hf_result =
                        (self.selected_hf_result + 1).min(self.hf_results.len() - 1);
                } else {
                    self.select_next_model();
                }
                None
            }
            KeyCode::Enter if self.active_tab == Tab::Models => self
                .models
                .get(self.selected_model)
                .map(|model| Action::SelectModel(model.path.clone())),
            KeyCode::Char('p') if self.active_tab == Tab::Models => self
                .models
                .get(self.selected_model)
                .map(|model| Action::CycleRuntimeProfile(model.path.clone())),
            KeyCode::Char('4') => {
                self.active_tab = Tab::Server;
                None
            }
            KeyCode::Char('5') => {
                self.active_tab = Tab::Settings;
                None
            }
            KeyCode::Tab => {
                self.next_tab();
                None
            }
            KeyCode::BackTab => {
                self.previous_tab();
                None
            }
            KeyCode::Char('?') => Some(Action::ShowHelp),
            KeyCode::Char('q') => Some(Action::Quit),
            KeyCode::Char('v') => Some(Action::CycleRuntimeSelection),
            KeyCode::Enter if self.first_run_onboarding => Some(Action::StartBuild),
            KeyCode::Char('p') if self.active_tab == Tab::Server => self
                .selected_server_model()
                .map(|model| Action::CycleRuntimeProfile(model.path)),
            KeyCode::Esc if self.first_run_onboarding => {
                self.first_run_onboarding = false;
                None
            }
            KeyCode::Char('d') => Some(Action::RunDetect),
            KeyCode::Char('b') => Some(Action::StartBuild),
            KeyCode::Char('B') => Some(Action::CleanBuild),
            KeyCode::Char('u') => Some(Action::CheckForUpdate),
            KeyCode::Char('s') => match self.active_tab {
                Tab::Server => match self.server_status {
                    ServerStatus::Stopped | ServerStatus::Failed { .. } => {
                        Some(Action::StartServer)
                    }
                    ServerStatus::Starting { .. } | ServerStatus::Ready { .. } => {
                        Some(Action::StopServer)
                    }
                },
                Tab::Settings => Some(Action::SaveSettings),
                Tab::Detect | Tab::Build | Tab::Models => None,
            },
            KeyCode::Char('m') if self.active_tab == Tab::Server => {
                let next_index = self.next_model_index()?;
                let model = self.models.get(next_index).cloned()?;
                match self.server_status {
                    ServerStatus::Stopped | ServerStatus::Failed { .. } => {
                        self.selected_model = next_index;
                        let applied_profile = self.select_model_path(model.path.clone());
                        self.status_message = format!("Selected {}", model.name);
                        if applied_profile {
                            self.status_message =
                                format!("Selected {}; runtime profile applied", model.name);
                        }
                        self.save_state_after("Model selected");
                    }
                    ServerStatus::Starting { .. } | ServerStatus::Ready { .. } => {
                        self.active_modal = Some(Modal::ConfirmModelSwap { model });
                        self.status_message = "Confirm server model swap".to_string();
                    }
                }
                None
            }
            KeyCode::Char('/') if self.active_tab == Tab::Models => Some(Action::OpenHfSearch),
            KeyCode::Char('D') if self.active_tab == Tab::Models => self
                .hf_results
                .get(self.selected_hf_result)
                .cloned()
                .map(Action::DownloadModel),
            KeyCode::Char('a') if self.active_tab == Tab::Models => Some(Action::AddModelAlias),
            KeyCode::Char('x') if self.active_tab == Tab::Models => self
                .models
                .get(self.selected_model)
                .cloned()
                .map(Action::DeleteModel),
            KeyCode::Char('r') if self.active_tab == Tab::Models => Some(Action::ScanModels),
            _ => None,
        }
    }

    fn handle_onboarding_key(&mut self, key: KeyEvent) -> Option<Action> {
        match self.onboarding_step {
            OnboardingStep::Scan => match key.code {
                KeyCode::Enter | KeyCode::Char('d') => Some(Action::RunDetect),
                KeyCode::Esc => {
                    self.first_run_onboarding = false;
                    None
                }
                _ => None,
            },
            OnboardingStep::HardwareSummary => match key.code {
                KeyCode::Enter => {
                    self.onboarding_step = OnboardingStep::Backend;
                    None
                }
                KeyCode::Esc => {
                    self.first_run_onboarding = false;
                    None
                }
                _ => None,
            },
            OnboardingStep::Backend => match key.code {
                KeyCode::Left | KeyCode::Right | KeyCode::Tab => {
                    self.onboarding_backend = Some(next_backend(
                        self.onboarding_backend
                            .clone()
                            .unwrap_or(BuildBackend::CpuFallback),
                    ));
                    None
                }
                KeyCode::Enter => {
                    let backend = self
                        .onboarding_backend
                        .clone()
                        .unwrap_or(BuildBackend::CpuFallback);
                    self.state.build.backend = backend_name(&backend);
                    self.state.build.archs = backend_archs(&backend);
                    self.save_state_after("Backend selected");
                    self.onboarding_step = OnboardingStep::ModelsDir;
                    None
                }
                KeyCode::Esc => {
                    self.first_run_onboarding = false;
                    None
                }
                _ => None,
            },
            OnboardingStep::ModelsDir => match key.code {
                KeyCode::Enter => {
                    let value = self.onboarding_models_dir_buffer.trim();
                    if value.is_empty() {
                        self.onboarding_error = Some("models directory is required".to_string());
                    } else {
                        self.state.model.models_dir = PathBuf::from(value);
                        self.save_state_after("Models directory selected");
                        self.onboarding_error = None;
                        self.onboarding_step = OnboardingStep::StarterModel;
                    }
                    None
                }
                KeyCode::Backspace => {
                    self.onboarding_models_dir_buffer.pop();
                    self.onboarding_error = None;
                    None
                }
                KeyCode::Char(value) => {
                    self.onboarding_models_dir_buffer.push(value);
                    self.onboarding_error = None;
                    None
                }
                KeyCode::Esc => {
                    self.first_run_onboarding = false;
                    None
                }
                _ => None,
            },
            OnboardingStep::StarterModel => match key.code {
                KeyCode::Char('d') | KeyCode::Char('/') => {
                    self.onboarding_step = OnboardingStep::ServerPort;
                    Some(Action::OpenHfSearch)
                }
                KeyCode::Enter => {
                    self.onboarding_step = OnboardingStep::ServerPort;
                    None
                }
                KeyCode::Esc => {
                    self.first_run_onboarding = false;
                    None
                }
                _ => None,
            },
            OnboardingStep::ServerPort => match key.code {
                KeyCode::Enter => match parse_onboarding_port(&self.onboarding_port_buffer) {
                    Ok(port) => {
                        self.state.server.port = port;
                        self.save_state_after("Server port configured");
                        self.onboarding_error = None;
                        self.onboarding_step = OnboardingStep::Done;
                        None
                    }
                    Err(error) => {
                        self.onboarding_error = Some(error);
                        None
                    }
                },
                KeyCode::Backspace => {
                    self.onboarding_port_buffer.pop();
                    self.onboarding_error = None;
                    None
                }
                KeyCode::Char(value) if value.is_ascii_digit() => {
                    self.onboarding_port_buffer.push(value);
                    self.onboarding_error = None;
                    None
                }
                KeyCode::Esc => {
                    self.first_run_onboarding = false;
                    None
                }
                _ => None,
            },
            OnboardingStep::Done => match key.code {
                KeyCode::Enter | KeyCode::Esc => {
                    self.first_run_onboarding = false;
                    self.active_tab = Tab::Build;
                    None
                }
                _ => None,
            },
        }
    }

    fn handle_modal_key(&mut self, key: KeyEvent) -> Option<Action> {
        match self.active_modal.take() {
            Some(Modal::AddAlias {
                mut buffer,
                mut error,
            }) => match key.code {
                KeyCode::Esc => None,
                KeyCode::Enter => {
                    let trimmed = buffer.trim();
                    if trimmed.is_empty() {
                        error = Some("path is required".to_string());
                        self.active_modal = Some(Modal::AddAlias { buffer, error });
                        None
                    } else {
                        Some(Action::ConfirmAddModelAlias(PathBuf::from(trimmed)))
                    }
                }
                KeyCode::Backspace => {
                    buffer.pop();
                    self.active_modal = Some(Modal::AddAlias {
                        buffer,
                        error: None,
                    });
                    None
                }
                KeyCode::Char(value) => {
                    buffer.push(value);
                    self.active_modal = Some(Modal::AddAlias {
                        buffer,
                        error: None,
                    });
                    None
                }
                _ => {
                    self.active_modal = Some(Modal::AddAlias { buffer, error });
                    None
                }
            },
            Some(Modal::ConfirmDelete { model }) => match key.code {
                KeyCode::Esc | KeyCode::Char('n') | KeyCode::Char('N') => None,
                KeyCode::Enter | KeyCode::Char('y') | KeyCode::Char('Y') => {
                    Some(Action::ConfirmDeleteModel(model))
                }
                _ => {
                    self.active_modal = Some(Modal::ConfirmDelete { model });
                    None
                }
            },
            Some(Modal::ConfirmModelSwap { model }) => match key.code {
                KeyCode::Esc | KeyCode::Char('n') | KeyCode::Char('N') => None,
                KeyCode::Enter | KeyCode::Char('y') | KeyCode::Char('Y') => {
                    Some(Action::ConfirmModelSwap(model))
                }
                _ => {
                    self.active_modal = Some(Modal::ConfirmModelSwap { model });
                    None
                }
            },
            Some(Modal::HfSearch {
                mut field,
                mut keywords,
                mut architecture,
                mut quant_filter,
                mut error,
            }) => match key.code {
                KeyCode::Esc => None,
                KeyCode::Tab | KeyCode::Down => {
                    field = next_hf_field(field);
                    self.active_modal = Some(Modal::HfSearch {
                        field,
                        keywords,
                        architecture,
                        quant_filter,
                        error,
                    });
                    None
                }
                KeyCode::BackTab | KeyCode::Up => {
                    field = previous_hf_field(field);
                    self.active_modal = Some(Modal::HfSearch {
                        field,
                        keywords,
                        architecture,
                        quant_filter,
                        error,
                    });
                    None
                }
                KeyCode::Left | KeyCode::Right if field == HfSearchField::Quant => {
                    quant_filter = next_quant_filter(quant_filter);
                    self.active_modal = Some(Modal::HfSearch {
                        field,
                        keywords,
                        architecture,
                        quant_filter,
                        error: None,
                    });
                    None
                }
                KeyCode::Backspace => {
                    match field {
                        HfSearchField::Keywords => {
                            keywords.pop();
                        }
                        HfSearchField::Architecture => {
                            architecture.pop();
                        }
                        HfSearchField::Quant => {
                            quant_filter = None;
                        }
                    }
                    self.active_modal = Some(Modal::HfSearch {
                        field,
                        keywords,
                        architecture,
                        quant_filter,
                        error: None,
                    });
                    None
                }
                KeyCode::Char(value) => {
                    match field {
                        HfSearchField::Keywords => keywords.push(value),
                        HfSearchField::Architecture => architecture.push(value),
                        HfSearchField::Quant => {
                            quant_filter = quant_from_char(value).or(quant_filter);
                        }
                    }
                    self.active_modal = Some(Modal::HfSearch {
                        field,
                        keywords,
                        architecture,
                        quant_filter,
                        error: None,
                    });
                    None
                }
                KeyCode::Enter => {
                    if keywords.trim().is_empty() {
                        error = Some("keywords are required".to_string());
                        self.active_modal = Some(Modal::HfSearch {
                            field,
                            keywords,
                            architecture,
                            quant_filter,
                            error,
                        });
                        None
                    } else {
                        Some(Action::SearchHf(HfSearchQuery {
                            keywords: keywords.trim().to_string(),
                            architecture: non_empty_filter(&architecture),
                            quant_filter,
                            max_results: 20,
                        }))
                    }
                }
                _ => {
                    self.active_modal = Some(Modal::HfSearch {
                        field,
                        keywords,
                        architecture,
                        quant_filter,
                        error,
                    });
                    None
                }
            },
            None => None,
        }
    }

    fn handle_build_event(&mut self, event: BuildEvent) {
        match event {
            BuildEvent::Started { flavor } => {
                self.active_build_flavor = Some(flavor);
                if flavor == lmml_compat::LlamaRuntimeFlavor::Prism {
                    invalidate_prism_verification(&mut self.state.build.prism);
                    self.save_state_after("Prism build started");
                }
            }
            BuildEvent::Cloning { url } => {
                self.build_running = true;
                self.push_build_log(format!("Cloning {url}"));
            }
            BuildEvent::CmakeConfiguring => {
                self.build_running = true;
                self.push_build_log("Configuring CMake");
            }
            BuildEvent::Compiling { line } => {
                self.build_running = true;
                self.push_build_log(line);
            }
            BuildEvent::Linking => {
                self.build_running = true;
                self.push_build_log("Linking");
            }
            BuildEvent::Completed {
                binary,
                fingerprint,
                backend,
                archs,
                sccache_used,
                verification,
                ..
            } => {
                self.build_running = false;
                let built_at = unix_timestamp_string();
                let verification = *verification;
                match fingerprint.flavor {
                    lmml_compat::LlamaRuntimeFlavor::Upstream => {
                        self.state.build.binary = binary.clone();
                        self.state.build.commit = fingerprint.commit;
                        self.state.build.cmake_hash =
                            lmml_build::hash_to_hex(&fingerprint.cmake_hash);
                        self.state.build.backend = backend_name(&backend);
                        self.state.build.archs = archs;
                        self.state.build.sccache_used = sccache_used;
                        self.state.build.last_built = built_at;
                    }
                    lmml_compat::LlamaRuntimeFlavor::Prism => {
                        let prism = &mut self.state.build.prism;
                        prism.source_url = fingerprint.source_url;
                        prism.binary = binary.clone();
                        prism.commit = fingerprint.commit;
                        prism.cmake_hash = lmml_build::hash_to_hex(&fingerprint.cmake_hash);
                        prism.backend = backend_name(&backend);
                        prism.archs = archs;
                        prism.sccache_used = sccache_used;
                        prism.last_built = built_at.clone();
                        prism.last_verified = built_at;
                        prism.verification_version = verification.version;
                        prism.verified_prism_tensor_types = verification.prism_tensor_types;
                        prism.verified_rocm_targets = verification.rocm_targets;
                        prism.verified_cuda_targets = verification.cuda_targets;
                        prism.verified_server_sha256 = verification.server_sha256;
                        prism.verified_hip_library = verification.hip_library.unwrap_or_default();
                        prism.verified_hip_library_sha256 =
                            verification.hip_library_sha256.unwrap_or_default();
                        prism.verified_cuda_library = verification.cuda_library.unwrap_or_default();
                        prism.verified_cuda_library_sha256 =
                            verification.cuda_library_sha256.unwrap_or_default();
                    }
                }
                self.active_build_flavor = None;
                self.build_binary = Some(binary.clone());
                self.build_error = None;
                self.push_build_log(format!("Build complete: {}", binary.display()));
                self.status_message = "Build complete".to_string();
                self.save_state_after("Build complete");
            }
            BuildEvent::Failed {
                last_error,
                log_tail,
            } => {
                self.build_running = false;
                let flavor = self
                    .active_build_flavor
                    .take()
                    .unwrap_or_else(|| self.state.build.selected_build_flavor());
                if flavor == lmml_compat::LlamaRuntimeFlavor::Prism {
                    invalidate_prism_verification(&mut self.state.build.prism);
                    self.save_state_after("Prism build failed");
                }
                for line in log_tail {
                    self.push_build_log(line);
                }
                self.build_error = Some(last_error.clone());
                self.status_message = format!("Build failed: {last_error}");
            }
            BuildEvent::Cancelled => {
                self.build_running = false;
                self.build_error = Some("cancelled".to_string());
                let flavor = self
                    .active_build_flavor
                    .take()
                    .unwrap_or_else(|| self.state.build.selected_build_flavor());
                match flavor {
                    lmml_compat::LlamaRuntimeFlavor::Upstream => {
                        self.state.build.cmake_hash.clear();
                        self.state.build.last_built.clear();
                    }
                    lmml_compat::LlamaRuntimeFlavor::Prism => {
                        self.state.build.prism.cmake_hash.clear();
                        self.state.build.prism.last_built.clear();
                        invalidate_prism_verification(&mut self.state.build.prism);
                    }
                }
                self.push_build_log("Build cancelled");
                self.status_message = "Build cancelled".to_string();
                self.save_state_after("Build cancelled");
            }
            BuildEvent::Skipped { reason } => {
                self.build_running = false;
                self.active_build_flavor = None;
                self.build_error = None;
                self.build_binary = Some(
                    self.state
                        .build
                        .runtime_binary(self.state.build.selected_build_flavor())
                        .to_path_buf(),
                );
                self.push_build_log(format!("Build skipped: {reason}"));
                self.status_message = "Build up to date".to_string();
            }
        }
    }

    fn sync_build_backend_after_detection(&mut self, profile: &SystemProfile) {
        let (backend_name, detected_archs, label) = match profile.recommended_backend() {
            BuildBackend::Cuda { archs } => (
                "Cuda",
                archs
                    .iter()
                    .map(|arch| (*arch).to_string())
                    .collect::<Vec<_>>(),
                "CUDA build archs",
            ),
            BuildBackend::Rocm { targets } => ("Rocm", targets, "ROCm build targets"),
            BuildBackend::Metal
            | BuildBackend::Vulkan
            | BuildBackend::CpuAvx2
            | BuildBackend::CpuAvx
            | BuildBackend::CpuFallback => return,
        };
        let flavor = self.state.build.selected_build_flavor();
        let (backend, persisted_archs) = match flavor {
            lmml_compat::LlamaRuntimeFlavor::Upstream => {
                (&self.state.build.backend, &mut self.state.build.archs)
            }
            lmml_compat::LlamaRuntimeFlavor::Prism => (
                &self.state.build.prism.backend,
                &mut self.state.build.prism.archs,
            ),
        };
        if backend != backend_name
            || detected_archs.is_empty()
            || detected_archs == *persisted_archs
        {
            return;
        }

        let previous = format_arch_list(persisted_archs);
        let current = format_arch_list(&detected_archs);
        *persisted_archs = detected_archs;
        match flavor {
            lmml_compat::LlamaRuntimeFlavor::Upstream => {
                self.state.build.cmake_hash.clear();
                self.state.build.last_built.clear();
            }
            lmml_compat::LlamaRuntimeFlavor::Prism => {
                self.state.build.prism.cmake_hash.clear();
                self.state.build.prism.last_built.clear();
                invalidate_prism_verification(&mut self.state.build.prism);
            }
        }
        let label = if flavor == lmml_compat::LlamaRuntimeFlavor::Prism {
            format!("prism {label}")
        } else {
            label.to_string()
        };
        self.detect_log
            .push(format!("{label} updated: {previous} -> {current}"));
    }

    fn invalidate_selected_prism_build(&mut self, reason: &str) {
        if self.state.build.selected_build_flavor() == lmml_compat::LlamaRuntimeFlavor::Prism {
            invalidate_prism_verification(&mut self.state.build.prism);
            self.save_state_after(reason);
        }
    }

    /// Build a `lmml-build` config from current app state.
    pub fn build_config(&self, clean: bool) -> lmml_build::BuildConfig {
        let flavor = self.state.build.selected_build_flavor();
        let (source_dir, configured_backend, configured_archs) = match flavor {
            lmml_compat::LlamaRuntimeFlavor::Upstream => (
                self.state.build.source_dir.clone(),
                self.state.build.backend.as_str(),
                self.state.build.archs.as_slice(),
            ),
            lmml_compat::LlamaRuntimeFlavor::Prism => (
                self.state.build.prism.source_dir.clone(),
                self.state.build.prism.backend.as_str(),
                self.state.build.prism.archs.as_slice(),
            ),
        };
        let requested_backend = if configured_backend == "Auto" {
            self.detect_profile
                .as_ref()
                .map(SystemProfile::recommended_backend)
                .unwrap_or(BuildBackend::CpuFallback)
        } else {
            backend_from_state(configured_backend, configured_archs)
        };
        let requested_backend =
            refresh_backend_for_detected_profile(requested_backend, self.detect_profile.as_ref());

        let cuda_compiler = matches!(requested_backend, BuildBackend::Cuda { .. })
            .then(|| detect_cuda_compiler_preference(&requested_backend))
            .flatten();
        let backend = if cuda_backend_dropped_by_selected_toolkit(
            &requested_backend,
            cuda_compiler.as_deref(),
        ) {
            fallback_non_cuda_backend(self.detect_profile.as_ref())
        } else {
            requested_backend
        };

        let mut config = lmml_build::BuildConfig::for_flavor(source_dir, backend, flavor);
        config.clean = clean;
        config.sccache = self
            .detect_profile
            .as_ref()
            .and_then(|profile| profile.sccache.clone());
        if matches!(config.backend, BuildBackend::Cuda { .. }) {
            config.cuda_compiler = cuda_compiler;
            config.cuda_glibc_compat_shim =
                cuda_glibc_compat_shim_needed(config.cuda_compiler.as_deref());
            config.cuda_host_compiler =
                detect_cuda_host_compiler_workaround(config.cuda_compiler.as_deref());
        }
        if matches!(config.backend, BuildBackend::Rocm { .. }) {
            config.rocm_hipcxx = self
                .detect_profile
                .as_ref()
                .and_then(|profile| profile.rocm.hip_clang_path.clone());
            config.rocm_hip_path = self
                .detect_profile
                .as_ref()
                .and_then(|profile| profile.rocm.hip_path.clone());
        }
        match flavor {
            lmml_compat::LlamaRuntimeFlavor::Upstream
                if self.state.build.track_mode == lmml_state::TrackMode::Tag
                    && !self.state.build.commit.is_empty() =>
            {
                config.git_ref = Some(self.state.build.commit.clone());
            }
            lmml_compat::LlamaRuntimeFlavor::Prism
                if !self.state.build.prism.requested_ref.is_empty() =>
            {
                config.git_ref = Some(self.state.build.prism.requested_ref.clone());
            }
            lmml_compat::LlamaRuntimeFlavor::Upstream | lmml_compat::LlamaRuntimeFlavor::Prism => {}
        }
        config
    }

    /// Return the model that should be served, preferring the visible selection.
    pub fn selected_server_model(&self) -> Option<ModelEntry> {
        if let Some(model) = self.models.get(self.selected_model) {
            return Some(model.clone());
        }
        let path = &self.state.model.last_used;
        if path.as_os_str().is_empty() {
            return None;
        }
        Some(ModelEntry {
            path: path.clone(),
            name: path
                .file_stem()
                .and_then(|name| name.to_str())
                .unwrap_or("selected model")
                .to_string(),
            size_bytes: path.metadata().map(|metadata| metadata.len()).unwrap_or(0),
            quant: "unknown".to_string(),
            context_length: None,
            architecture: None,
            runtime: lmml_models::GgufRuntimeRequirement::Unsupported {
                tensor_types: std::collections::BTreeSet::new(),
            },
            tensor_types: std::collections::BTreeSet::new(),
            prism_metadata_keys: std::collections::BTreeSet::new(),
            aliased: false,
        })
    }

    /// Build a compat server config from persisted settings and model fit.
    pub fn server_config(&self, model: &ModelEntry) -> lmml_compat::ServerConfig {
        let has_model_profile = self
            .state
            .model
            .runtime_profile_for_path(&model.path)
            .is_some();
        let server = self.server_settings_for_model(model);
        let n_gpu_layers = self.resolve_server_gpu_layers(model, &server).launch;
        let mut config = lmml_compat::ServerConfig {
            model: model.path.clone(),
            port: server.port,
            host: server.host.clone(),
            ctx_size: server.ctx_size,
            n_gpu_layers,
            batch_size: server.batch_size,
            ubatch_size: server.ubatch_size,
            threads: server.threads,
            flash_attn: server.flash_attn,
            mlock: server.mlock,
            api_key: (!server.api_key.is_empty()).then(|| server.api_key.clone()),
            chat_template: (!server.chat_template.is_empty()).then(|| server.chat_template.clone()),
            jinja: server.jinja,
            extra_args: server.extra_args.clone(),
        };
        apply_qwen_server_safeguards(model, &mut config);
        apply_prism_initial_safeguards(model, has_model_profile, &mut config);
        config
    }

    /// Stage the exact model/runtime pair that a server start will attempt.
    pub fn prepare_server_start(
        &mut self,
        model: ModelEntry,
        runtime: &crate::runtime_cli::ResolvedModelRuntime,
    ) {
        self.pending_server_model = Some(model);
        self.pending_runtime_flavor = Some(runtime.flavor);
        self.pending_runtime_binary = Some(runtime.binary.clone());
    }

    fn commit_pending_server(&mut self) {
        self.active_server_model = self.pending_server_model.take();
        self.active_runtime_flavor = self.pending_runtime_flavor.take();
        self.active_runtime_binary = self.pending_runtime_binary.take();
    }

    fn clear_pending_server(&mut self) {
        self.pending_server_model = None;
        self.pending_runtime_flavor = None;
        self.pending_runtime_binary = None;
    }

    /// Estimate model VRAM fit using live detection first, then cached detection.
    pub fn model_vram_fit(&self, model: &ModelEntry) -> VramFit {
        if let Some(vram_mb) = self.detect_profile.as_ref().and_then(max_detected_vram_mb) {
            return model.vram_fit_for_vram_mb(vram_mb);
        }
        if let Some(vram_mb) = self
            .state
            .system_profile
            .as_ref()
            .and_then(max_cached_vram_mb)
        {
            return model.vram_fit_for_vram_mb(vram_mb);
        }
        VramFit::CpuOnly
    }

    /// Return the model's recommended `llama-server -ngl` value for this host.
    pub fn model_recommended_ngl(&self, model: &ModelEntry) -> i32 {
        recommended_ngl_from_fit(&self.model_vram_fit(model))
    }

    /// Return the GPU layer setting as it will be passed to `llama-server`.
    pub fn server_gpu_layers_label(&self, model: Option<&ModelEntry>) -> String {
        let Some(model) = model else {
            return explicit_or_auto_gpu_layers_label(self.state.server.n_gpu_layers);
        };
        let server = self.server_settings_for_model(model);
        self.resolve_server_gpu_layers(model, &server).label()
    }

    fn server_settings_for_model(&self, model: &ModelEntry) -> lmml_state::ServerConfig {
        self.state
            .model
            .runtime_profile_for_path(&model.path)
            .map(|profile| resolved_profile_server(&model.path, profile))
            .unwrap_or_else(|| self.state.server.clone())
    }

    fn resolve_server_gpu_layers(
        &self,
        model: &ModelEntry,
        server: &lmml_state::ServerConfig,
    ) -> ResolvedGpuLayers {
        if server.n_gpu_layers != -1 {
            return ResolvedGpuLayers {
                launch: server.n_gpu_layers,
                source: GpuLayerResolutionSource::Explicit,
            };
        }

        if let Some(vram_mb) = self.detect_profile.as_ref().and_then(max_detected_vram_mb) {
            return ResolvedGpuLayers {
                launch: model.recommended_ngl_for_vram_mb(vram_mb),
                source: GpuLayerResolutionSource::LiveProbe,
            };
        }

        if let Some(vram_mb) = self
            .state
            .system_profile
            .as_ref()
            .and_then(max_cached_vram_mb)
        {
            return ResolvedGpuLayers {
                launch: model.recommended_ngl_for_vram_mb(vram_mb),
                source: GpuLayerResolutionSource::CachedProbe,
            };
        }

        ResolvedGpuLayers {
            launch: -1,
            source: GpuLayerResolutionSource::LlamaAuto,
        }
    }

    fn select_model_path(&mut self, path: PathBuf) -> bool {
        self.state.model.last_used = path.clone();
        if let Some(profile) = self.state.model.runtime_profile_for_path(&path).cloned() {
            self.state.model.active_profile = profile.name.clone();
            self.state.server = resolved_profile_server(&path, &profile);
            true
        } else {
            false
        }
    }

    fn push_build_log(&mut self, line: impl Into<String>) {
        self.build_log.push(line.into());
        const MAX_BUILD_LOG_LINES: usize = 500;
        if self.build_log.len() > MAX_BUILD_LOG_LINES {
            let overflow = self.build_log.len() - MAX_BUILD_LOG_LINES;
            self.build_log.drain(0..overflow);
        }
    }

    pub(crate) fn save_state_after(&mut self, success_message: &str) {
        let result = if let Some(path) = &self.state_save_path {
            self.state.save_to_path(path)
        } else {
            self.state.save()
        };
        if let Err(error) = result {
            self.status_message = format!("{success_message}; state save failed: {error}");
        }
    }

    fn next_tab(&mut self) {
        let next = (self.active_tab.index() + 1) % Tab::ALL.len();
        self.active_tab = Tab::ALL[next];
    }

    fn previous_tab(&mut self) {
        let current = self.active_tab.index();
        let previous = if current == 0 {
            Tab::ALL.len() - 1
        } else {
            current - 1
        };
        self.active_tab = Tab::ALL[previous];
    }

    fn select_next_model(&mut self) {
        if !self.models.is_empty() {
            self.selected_model = (self.selected_model + 1).min(self.models.len() - 1);
        }
    }

    fn select_previous_model(&mut self) {
        self.selected_model = self.selected_model.saturating_sub(1);
    }

    fn next_model_index(&self) -> Option<usize> {
        if self.models.is_empty() {
            None
        } else {
            Some((self.selected_model + 1).min(self.models.len() - 1))
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
struct ResolvedGpuLayers {
    launch: i32,
    source: GpuLayerResolutionSource,
}

impl ResolvedGpuLayers {
    fn label(self) -> String {
        match self.source {
            GpuLayerResolutionSource::Explicit => self.launch.to_string(),
            GpuLayerResolutionSource::LiveProbe => format!("auto -> {}", self.launch),
            GpuLayerResolutionSource::CachedProbe => {
                format!("auto -> {} (cached VRAM)", self.launch)
            }
            GpuLayerResolutionSource::LlamaAuto => "auto -> -1".to_string(),
        }
    }
}

#[derive(Debug, Clone, Copy, PartialEq, Eq)]
enum GpuLayerResolutionSource {
    Explicit,
    LiveProbe,
    CachedProbe,
    LlamaAuto,
}

fn explicit_or_auto_gpu_layers_label(n_gpu_layers: i32) -> String {
    if n_gpu_layers == -1 {
        "auto -> -1".to_string()
    } else {
        n_gpu_layers.to_string()
    }
}

fn recommended_ngl_from_fit(fit: &VramFit) -> i32 {
    match fit {
        VramFit::Full { .. } => -1,
        VramFit::Partial {
            recommended_ngl, ..
        } => *recommended_ngl,
        VramFit::TooLarge { .. } | VramFit::CpuOnly => 0,
    }
}

fn resolved_profile_server(
    model_path: &Path,
    profile: &lmml_state::ModelRuntimeProfile,
) -> lmml_state::ServerConfig {
    let mut server = profile.server.clone();
    let Some(model_dir) = model_path.parent() else {
        return server;
    };

    let sidecar_files = [
        ("-md", "mtp-gemma-4-12B-it.gguf"),
        ("--model-draft", "mtp-gemma-4-12B-it.gguf"),
        ("--spec-draft-model", "mtp-gemma-4-12B-it.gguf"),
        ("--mmproj", "mmproj-Qwen3.5-9B-BF16.gguf"),
    ];
    for index in 0..server.extra_args.len().saturating_sub(1) {
        let Some((_, filename)) = sidecar_files
            .iter()
            .find(|(flag, _)| server.extra_args[index] == *flag)
        else {
            continue;
        };
        let value = Path::new(&server.extra_args[index + 1]);
        if value.file_name().and_then(|name| name.to_str()) == Some(*filename) {
            server.extra_args[index + 1] = model_dir.join(filename).to_string_lossy().into_owned();
        }
    }
    server
}

fn apply_qwen_server_safeguards(model: &ModelEntry, config: &mut lmml_compat::ServerConfig) {
    if !is_qwen35_or_qwen36_model(model) {
        return;
    }

    push_missing_arg_pair(&mut config.extra_args, "--reasoning-format", "none");
    if config.ctx_size > 32_768 {
        push_missing_any_arg_pair(
            &mut config.extra_args,
            &["-ctk", "--cache-type-k"],
            "-ctk",
            "q8_0",
        );
        push_missing_any_arg_pair(
            &mut config.extra_args,
            &["-ctv", "--cache-type-v"],
            "-ctv",
            "q8_0",
        );
    }
}

fn apply_prism_initial_safeguards(
    model: &ModelEntry,
    has_model_profile: bool,
    config: &mut lmml_compat::ServerConfig,
) {
    if model.runtime != lmml_models::GgufRuntimeRequirement::Prism || has_model_profile {
        return;
    }

    config.flash_attn = true;
    config.jinja = true;
    set_arg_pair(
        &mut config.extra_args,
        &["--parallel", "-np"],
        "--parallel",
        "1",
    );
    set_arg_pair(&mut config.extra_args, &["--temp"], "--temp", "1.0");
    set_arg_pair(&mut config.extra_args, &["--top-p"], "--top-p", "0.95");
    set_arg_pair(&mut config.extra_args, &["--top-k"], "--top-k", "20");
}

fn is_qwen35_or_qwen36_model(model: &ModelEntry) -> bool {
    let matched = lmml_models::catalog::match_known_model_name(&model.name).or_else(|| {
        model
            .path
            .file_name()
            .and_then(|name| name.to_str())
            .and_then(lmml_models::catalog::match_known_model_name)
    });
    matched.is_some_and(|variant| {
        matches!(
            variant.family,
            lmml_models::catalog::LlmFamily::Qwen35
                | lmml_models::catalog::LlmFamily::Qwen36
                | lmml_models::catalog::LlmFamily::Qwen38
        )
    })
}

fn push_missing_arg_pair(extra_args: &mut Vec<String>, flag: &str, value: &str) {
    if !extra_args.iter().any(|arg| arg == flag) {
        extra_args.push(flag.to_string());
        extra_args.push(value.to_string());
    }
}

fn push_missing_any_arg_pair(
    extra_args: &mut Vec<String>,
    existing_flags: &[&str],
    flag: &str,
    value: &str,
) {
    if !existing_flags
        .iter()
        .any(|existing| extra_args.iter().any(|arg| arg == existing))
    {
        extra_args.push(flag.to_string());
        extra_args.push(value.to_string());
    }
}

fn set_arg_pair(extra_args: &mut Vec<String>, flags: &[&str], flag: &str, value: &str) {
    if let Some(index) = extra_args
        .iter()
        .position(|argument| flags.contains(&argument.as_str()))
    {
        if let Some(existing) = extra_args.get_mut(index + 1) {
            *existing = value.to_string();
        } else {
            extra_args.push(value.to_string());
        }
    } else {
        extra_args.push(flag.to_string());
        extra_args.push(value.to_string());
    }
}

fn backend_from_state(backend: &str, archs: &[String]) -> BuildBackend {
    match backend {
        "Cuda" => BuildBackend::Cuda {
            archs: archs
                .iter()
                .filter_map(|arch| owned_arch_to_static(arch))
                .collect(),
        },
        "Metal" => BuildBackend::Metal,
        "Rocm" => BuildBackend::Rocm {
            targets: archs.to_vec(),
        },
        "Vulkan" => BuildBackend::Vulkan,
        "CpuAvx2" => BuildBackend::CpuAvx2,
        "CpuAvx" => BuildBackend::CpuAvx,
        "CpuFallback" => BuildBackend::CpuFallback,
        _ => BuildBackend::CpuFallback,
    }
}

fn backend_name(backend: &BuildBackend) -> String {
    match backend {
        BuildBackend::Cuda { .. } => "Cuda",
        BuildBackend::Metal => "Metal",
        BuildBackend::Rocm { .. } => "Rocm",
        BuildBackend::Vulkan => "Vulkan",
        BuildBackend::CpuAvx2 => "CpuAvx2",
        BuildBackend::CpuAvx => "CpuAvx",
        BuildBackend::CpuFallback => "CpuFallback",
    }
    .to_string()
}

fn backend_archs(backend: &BuildBackend) -> Vec<String> {
    match backend {
        BuildBackend::Cuda { archs } => archs.iter().map(|arch| (*arch).to_string()).collect(),
        BuildBackend::Rocm { targets } => targets.clone(),
        BuildBackend::Metal
        | BuildBackend::Vulkan
        | BuildBackend::CpuAvx2
        | BuildBackend::CpuAvx
        | BuildBackend::CpuFallback => Vec::new(),
    }
}

fn refresh_backend_for_detected_profile(
    backend: BuildBackend,
    profile: Option<&SystemProfile>,
) -> BuildBackend {
    match backend {
        backend @ BuildBackend::Cuda { .. } => {
            match profile.map(SystemProfile::recommended_backend) {
                Some(BuildBackend::Cuda { archs }) if !archs.is_empty() => {
                    BuildBackend::Cuda { archs }
                }
                Some(BuildBackend::Cuda { .. })
                | Some(BuildBackend::Metal)
                | Some(BuildBackend::Rocm { .. })
                | Some(BuildBackend::Vulkan)
                | Some(BuildBackend::CpuAvx2)
                | Some(BuildBackend::CpuAvx)
                | Some(BuildBackend::CpuFallback)
                | None => backend,
            }
        }
        BuildBackend::Rocm { targets } => match profile.map(SystemProfile::recommended_backend) {
            Some(BuildBackend::Rocm { targets: detected }) if !detected.is_empty() => {
                BuildBackend::Rocm { targets: detected }
            }
            Some(BuildBackend::Cuda { .. })
            | Some(BuildBackend::Metal)
            | Some(BuildBackend::Rocm { .. })
            | Some(BuildBackend::Vulkan)
            | Some(BuildBackend::CpuAvx2)
            | Some(BuildBackend::CpuAvx)
            | Some(BuildBackend::CpuFallback)
            | None => BuildBackend::Rocm { targets },
        },
        backend => backend,
    }
}

fn invalidate_prism_verification(prism: &mut lmml_state::RuntimeFlavorBuildState) {
    prism.last_verified.clear();
    prism.verification_version = 0;
    prism.verified_prism_tensor_types.clear();
    prism.verified_rocm_targets.clear();
    prism.verified_cuda_targets.clear();
    prism.verified_server_sha256.clear();
    prism.verified_hip_library.clear();
    prism.verified_hip_library_sha256.clear();
    prism.verified_cuda_library.clear();
    prism.verified_cuda_library_sha256.clear();
}

fn format_arch_list(archs: &[String]) -> String {
    if archs.is_empty() {
        "none".to_string()
    } else {
        archs.join(",")
    }
}

fn detected_gpu_names(profile: &SystemProfile) -> Vec<String> {
    profile
        .gpus
        .iter()
        .map(|gpu| gpu.name.clone())
        .chain(
            profile
                .rocm
                .devices
                .iter()
                .map(|device| device.name.clone()),
        )
        .collect()
}

fn detected_vram_mb(profile: &SystemProfile) -> Vec<u64> {
    profile
        .gpus
        .iter()
        .map(|gpu| gpu.memory_total_mb)
        .chain(
            profile
                .rocm
                .devices
                .iter()
                .filter_map(|device| device.vram.map(|memory| memory.total_mb)),
        )
        .collect()
}

fn max_detected_vram_mb(profile: &SystemProfile) -> Option<u64> {
    detected_vram_mb(profile).into_iter().max()
}

fn max_cached_vram_mb(profile: &lmml_state::SystemProfile) -> Option<u64> {
    profile.vram_mb.iter().copied().max()
}

fn fallback_non_cuda_backend(profile: Option<&SystemProfile>) -> BuildBackend {
    if let Some(profile) = profile {
        if profile.metal.available {
            return BuildBackend::Metal;
        }
        if profile.rocm.available {
            return BuildBackend::Rocm {
                targets: profile.rocm.targets.clone(),
            };
        }
        if profile.vulkan.available {
            return BuildBackend::Vulkan;
        }
        if profile.cpu.avx2 {
            return BuildBackend::CpuAvx2;
        }
        if profile.cpu.avx {
            return BuildBackend::CpuAvx;
        }
    }
    BuildBackend::CpuFallback
}

fn next_backend(current: BuildBackend) -> BuildBackend {
    match current {
        BuildBackend::Cuda { .. } => BuildBackend::Metal,
        BuildBackend::Metal => BuildBackend::Rocm {
            targets: Vec::new(),
        },
        BuildBackend::Rocm { .. } => BuildBackend::Vulkan,
        BuildBackend::Vulkan => BuildBackend::CpuAvx2,
        BuildBackend::CpuAvx2 => BuildBackend::CpuAvx,
        BuildBackend::CpuAvx => BuildBackend::CpuFallback,
        BuildBackend::CpuFallback => BuildBackend::Cuda { archs: Vec::new() },
    }
}

fn parse_onboarding_port(value: &str) -> Result<u16, String> {
    match value.trim().parse::<u16>() {
        Ok(0) => Err("port must be between 1 and 65535".to_string()),
        Ok(port) => Ok(port),
        Err(_error) => Err("port must be between 1 and 65535".to_string()),
    }
}

fn unix_timestamp_string() -> String {
    std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|duration| duration.as_secs().to_string())
        .unwrap_or_else(|_| "0".to_string())
}

fn owned_arch_to_static(arch: &str) -> Option<&'static str> {
    match arch {
        "sm_37" => Some("sm_37"),
        "sm_50" => Some("sm_50"),
        "sm_52" => Some("sm_52"),
        "sm_53" => Some("sm_53"),
        "sm_60" => Some("sm_60"),
        "sm_61" => Some("sm_61"),
        "sm_62" => Some("sm_62"),
        "sm_70" => Some("sm_70"),
        "sm_72" => Some("sm_72"),
        "sm_75" => Some("sm_75"),
        "sm_80" => Some("sm_80"),
        "sm_86" => Some("sm_86"),
        "sm_87" => Some("sm_87"),
        "sm_89" => Some("sm_89"),
        "sm_90" => Some("sm_90"),
        "sm_90a" => Some("sm_90a"),
        "sm_100" => Some("sm_100"),
        "sm_100a" => Some("sm_100a"),
        "sm_101" => Some("sm_101"),
        "sm_101a" => Some("sm_101a"),
        "sm_102" => Some("sm_102"),
        "sm_102a" => Some("sm_102a"),
        "sm_120" => Some("sm_120"),
        "sm_120a" => Some("sm_120a"),
        _ => None,
    }
}

fn next_hf_field(field: HfSearchField) -> HfSearchField {
    match field {
        HfSearchField::Keywords => HfSearchField::Architecture,
        HfSearchField::Architecture => HfSearchField::Quant,
        HfSearchField::Quant => HfSearchField::Keywords,
    }
}

fn previous_hf_field(field: HfSearchField) -> HfSearchField {
    match field {
        HfSearchField::Keywords => HfSearchField::Quant,
        HfSearchField::Architecture => HfSearchField::Keywords,
        HfSearchField::Quant => HfSearchField::Architecture,
    }
}

fn next_quant_filter(current: Option<QuantTier>) -> Option<QuantTier> {
    match current {
        None => Some(QuantTier::Q4),
        Some(QuantTier::Q4) => Some(QuantTier::Q5),
        Some(QuantTier::Q5) => Some(QuantTier::Q6),
        Some(QuantTier::Q6) => Some(QuantTier::Q8),
        Some(QuantTier::Q8) => Some(QuantTier::F16),
        Some(QuantTier::F16) => Some(QuantTier::F32),
        Some(QuantTier::F32) => None,
    }
}

fn quant_from_char(value: char) -> Option<QuantTier> {
    match value.to_ascii_lowercase() {
        '4' => Some(QuantTier::Q4),
        '5' => Some(QuantTier::Q5),
        '6' => Some(QuantTier::Q6),
        '8' => Some(QuantTier::Q8),
        'h' => Some(QuantTier::F16),
        'f' => Some(QuantTier::F32),
        _ => None,
    }
}

fn non_empty_filter(value: &str) -> Option<String> {
    let trimmed = value.trim();
    (!trimmed.is_empty()).then(|| trimmed.to_string())
}

fn detect_cuda_compiler_preference(backend: &BuildBackend) -> Option<PathBuf> {
    detect_cuda_compiler_override().or_else(|| preferred_legacy_cuda_compiler(backend))
}

fn detect_cuda_compiler_override() -> Option<PathBuf> {
    ["LMML_CUDA_COMPILER", "CUDACXX"]
        .into_iter()
        .filter_map(std::env::var_os)
        .map(PathBuf::from)
        .find(|path| path.exists())
}

fn preferred_legacy_cuda_compiler(backend: &BuildBackend) -> Option<PathBuf> {
    if !cuda_backend_targets_legacy_archs(backend) {
        return None;
    }

    nvcc_candidates()
        .into_iter()
        .filter(|path| path.is_absolute() && path.exists())
        .find(|path| {
            nvcc_version_output_for(path)
                .as_deref()
                .is_some_and(cuda_major_works_for_legacy_archs)
        })
}

fn cuda_backend_targets_legacy_archs(backend: &BuildBackend) -> bool {
    match backend {
        BuildBackend::Cuda { archs } => {
            !archs.is_empty()
                && archs
                    .iter()
                    .all(|arch| cuda_arch_number(arch).is_some_and(|number| number <= 75))
        }
        BuildBackend::Metal
        | BuildBackend::Rocm { .. }
        | BuildBackend::Vulkan
        | BuildBackend::CpuAvx2
        | BuildBackend::CpuAvx
        | BuildBackend::CpuFallback => false,
    }
}

fn cuda_backend_dropped_by_selected_toolkit(
    backend: &BuildBackend,
    cuda_compiler: Option<&Path>,
) -> bool {
    if !cuda_backend_targets_archs_dropped_by_cuda13(backend) {
        return false;
    }
    let nvcc_output = match cuda_compiler {
        Some(cuda_compiler) => nvcc_version_output_for(cuda_compiler),
        None => nvcc_version_output(),
    };
    nvcc_output
        .as_deref()
        .is_some_and(|output| cuda_backend_dropped_by_toolkit_version(backend, output))
}

fn cuda_backend_dropped_by_toolkit_version(
    backend: &BuildBackend,
    nvcc_version_output: &str,
) -> bool {
    cuda_backend_targets_archs_dropped_by_cuda13(backend)
        && parsed_cuda_major(nvcc_version_output).is_some_and(|major| major >= 13)
}

fn cuda_backend_targets_archs_dropped_by_cuda13(backend: &BuildBackend) -> bool {
    match backend {
        BuildBackend::Cuda { archs } => archs
            .iter()
            .any(|arch| cuda_arch_number(arch).is_some_and(|number| number <= 72)),
        BuildBackend::Metal
        | BuildBackend::Rocm { .. }
        | BuildBackend::Vulkan
        | BuildBackend::CpuAvx2
        | BuildBackend::CpuAvx
        | BuildBackend::CpuFallback => false,
    }
}

fn cuda_arch_number(arch: &str) -> Option<u32> {
    arch.strip_prefix("sm_")
        .unwrap_or(arch)
        .trim_end_matches('a')
        .parse()
        .ok()
}

fn cuda_major_works_for_legacy_archs(nvcc_version_output: &str) -> bool {
    parsed_cuda_major(nvcc_version_output).is_some_and(|major| (11..=12).contains(&major))
}

fn cuda_glibc_compat_shim_needed(cuda_compiler: Option<&Path>) -> bool {
    let nvcc_output = match cuda_compiler {
        Some(cuda_compiler) => nvcc_version_output_for(cuda_compiler),
        None => nvcc_version_output(),
    };
    nvcc_output
        .as_deref()
        .is_some_and(cuda_glibc_compat_shim_needed_for_version)
}

fn cuda_glibc_compat_shim_needed_for_version(nvcc_version_output: &str) -> bool {
    parsed_cuda_major(nvcc_version_output).is_some_and(|major| major >= 13)
}

fn detect_cuda_host_compiler_workaround(cuda_compiler: Option<&Path>) -> Option<PathBuf> {
    let nvcc_output = match cuda_compiler {
        Some(cuda_compiler) => nvcc_version_output_for(cuda_compiler),
        None => nvcc_version_output(),
    }?;
    let compiler_version = compiler_version_output("g++")?;
    let candidate_majors = cuda_host_compiler_majors_for_versions(&nvcc_output, &compiler_version)?;
    cuda_host_compiler_candidate(&candidate_majors)
}

fn cuda_host_compiler_majors_for_versions(
    nvcc_version_output: &str,
    compiler_version_output: &str,
) -> Option<Vec<u32>> {
    let cuda_major = parsed_cuda_major(nvcc_version_output)?;
    let compiler_major = parsed_major_version(compiler_version_output)?;
    if cuda_major >= 13 && compiler_major >= 15 {
        return Some(vec![14, 13, 12, 11]);
    }
    if cuda_major == 11 && compiler_major >= 13 {
        return Some(vec![11, 10, 9]);
    }
    None
}

fn compiler_version_output(program: &str) -> Option<String> {
    std::process::Command::new(program)
        .arg("-dumpfullversion")
        .arg("-dumpversion")
        .output()
        .ok()
        .filter(|output| output.status.success())
        .and_then(|output| String::from_utf8(output.stdout).ok())
}

fn cuda_host_compiler_candidate(majors: &[u32]) -> Option<PathBuf> {
    majors
        .iter()
        .map(|major| PathBuf::from(format!("/usr/bin/g++-{major}")))
        .find(|path| path.exists() && compiler_path_major(path).is_some())
}

fn compiler_path_major(path: &Path) -> Option<u32> {
    let output = std::process::Command::new(path)
        .arg("-dumpfullversion")
        .arg("-dumpversion")
        .output()
        .ok()
        .filter(|output| output.status.success())?;
    let version = String::from_utf8(output.stdout).ok()?;
    parsed_major_version(&version)
}

fn nvcc_version_output() -> Option<String> {
    nvcc_candidates()
        .into_iter()
        .find_map(|nvcc| nvcc_version_output_for(&nvcc))
}

fn nvcc_version_output_for(nvcc: &Path) -> Option<String> {
    let output = std::process::Command::new(nvcc)
        .arg("--version")
        .output()
        .ok()
        .filter(|output| output.status.success())?;
    String::from_utf8(output.stdout).ok()
}

fn nvcc_candidates() -> Vec<PathBuf> {
    let mut candidates = Vec::new();
    push_unique_path(&mut candidates, PathBuf::from("nvcc"));
    for env_name in ["CUDA_HOME", "CUDA_PATH"] {
        if let Some(path) = std::env::var_os(env_name) {
            push_unique_path(
                &mut candidates,
                PathBuf::from(path).join("bin").join("nvcc"),
            );
        }
    }
    push_unique_path(&mut candidates, PathBuf::from("/usr/local/cuda/bin/nvcc"));
    if let Ok(entries) = std::fs::read_dir("/usr/local") {
        let mut cuda_dirs = entries
            .filter_map(Result::ok)
            .map(|entry| entry.path())
            .filter(|path| {
                path.file_name()
                    .and_then(|name| name.to_str())
                    .is_some_and(|name| name.starts_with("cuda-"))
            })
            .collect::<Vec<_>>();
        cuda_dirs.sort();
        cuda_dirs.reverse();
        for cuda_dir in cuda_dirs {
            push_unique_path(&mut candidates, cuda_dir.join("bin").join("nvcc"));
        }
    }
    candidates
}

fn push_unique_path(paths: &mut Vec<PathBuf>, path: PathBuf) {
    if !paths.iter().any(|existing| paths_equal(existing, &path)) {
        paths.push(path);
    }
}

fn paths_equal(left: &Path, right: &Path) -> bool {
    left == right
}

fn parsed_cuda_major(output: &str) -> Option<u32> {
    output
        .split("release ")
        .nth(1)
        .and_then(|tail| parsed_major_version(tail.trim_start()))
}

fn parsed_major_version(output: &str) -> Option<u32> {
    output
        .split(|ch: char| !ch.is_ascii_digit())
        .find(|part| !part.is_empty())
        .and_then(|part| part.parse().ok())
}

impl Default for App {
    fn default() -> Self {
        Self::new_with_state(PersistentState::default())
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use crossterm::event::KeyEvent;

    #[test]
    fn number_keys_select_tabs() {
        let mut app = App::default();
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('4'))));
        assert_eq!(app.active_tab, Tab::Server);
    }

    #[test]
    fn tab_cycles_forward_and_backward() {
        let mut app = App::default();
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Tab)));
        assert_eq!(app.active_tab, Tab::Build);
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::BackTab)));
        assert_eq!(app.active_tab, Tab::Detect);
    }

    #[test]
    fn help_and_quit_are_actions() {
        let mut app = App::default();
        let help = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('?'))));
        assert_eq!(help, Some(Action::ShowHelp));
        app.dispatch(help.expect("help action"));
        assert!(app.show_help);

        let quit = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('q'))));
        assert_eq!(quit, Some(Action::Quit));
        app.dispatch(quit.expect("quit action"));
        assert!(app.should_quit);
    }

    #[test]
    fn build_events_update_status_and_cap_log() {
        let mut app = App::default();
        for index in 0..505 {
            app.handle_event(AppEvent::BuildEvent(BuildEvent::Compiling {
                line: format!("line {index}"),
            }));
        }
        assert_eq!(app.build_log.len(), 500);
        assert!(app.build_running);

        app.handle_event(AppEvent::BuildEvent(BuildEvent::Failed {
            last_error: "cmake failed".to_string(),
            log_tail: vec!["tail".to_string()],
        }));
        assert!(!app.build_running);
        assert_eq!(app.build_error, Some("cmake failed".to_string()));

        let tempdir = tempfile::tempdir().expect("tempdir");
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.state.build.cmake_hash = "stale".to_string();
        app.handle_event(AppEvent::BuildEvent(BuildEvent::Cancelled));
        assert!(!app.build_running);
        assert_eq!(app.build_error, Some("cancelled".to_string()));
        assert!(app.state.build.cmake_hash.is_empty());
    }

    #[test]
    fn detect_complete_refreshes_stale_cuda_archs_after_gpu_upgrade() {
        let mut app = App::default();
        app.state.build.backend = "Cuda".to_string();
        app.state.build.archs = vec!["sm_61".to_string()];
        app.state.build.cmake_hash = "stale".to_string();
        app.state.build.last_built = "old".to_string();

        let mut profile = cuda_profile();
        profile.cuda = lmml_detect::CudaCompatibility::Compatible {
            archs: vec!["sm_120"],
        };
        profile.gpus = vec![lmml_detect::GpuInfo {
            name: "NVIDIA GeForce RTX 5060 Ti".to_string(),
            memory_total_mb: 16_384,
            compute_cap: "12.0".to_string(),
            arch: Some("sm_120"),
        }];

        app.handle_event(AppEvent::DetectComplete(Box::new(profile)));

        assert_eq!(app.state.build.backend, "Cuda");
        assert_eq!(app.state.build.archs, vec!["sm_120"]);
        assert!(app.state.build.cmake_hash.is_empty());
        assert!(app.state.build.last_built.is_empty());
        assert!(app
            .detect_log
            .iter()
            .any(|line| line == "CUDA build archs updated: sm_61 -> sm_120"));
        assert_eq!(
            app.build_config(false).backend,
            BuildBackend::Cuda {
                archs: vec!["sm_120"]
            }
        );
    }

    #[test]
    fn detect_complete_caches_rocm_gpu_names_and_vram() {
        let mut app = App::default();
        let mut profile = cuda_profile();
        profile.cuda = lmml_detect::CudaCompatibility::NoGpu;
        profile.gpus.clear();
        profile.rocm = lmml_detect::RocmSupport {
            available: true,
            targets: vec!["gfx1100".to_string()],
            devices: vec![lmml_detect::RocmGpuInfo {
                name: "AMD Radeon RX 7900 XTX".to_string(),
                target: Some("gfx1100".to_string()),
                vram: Some(lmml_detect::GpuVramInfo {
                    total_mb: 24_576,
                    used_mb: 1_024,
                    free_mb: 23_552,
                }),
            }],
            ..lmml_detect::RocmSupport::default()
        };

        app.handle_event(AppEvent::DetectComplete(Box::new(profile)));

        let cached = app.state.system_profile.expect("cached system profile");
        assert_eq!(cached.gpu_names, vec!["AMD Radeon RX 7900 XTX".to_string()]);
        assert_eq!(cached.gpu_archs, Vec::<String>::new());
        assert_eq!(cached.rocm_targets, vec!["gfx1100".to_string()]);
        assert_eq!(cached.vram_mb, vec![24_576]);
    }

    #[test]
    fn build_config_uses_persisted_backend_and_clean_flag() {
        let mut app = App::default();
        app.state.build.backend = "Cuda".to_string();
        app.state.build.archs = vec!["sm_86".to_string()];
        let config = app.build_config(true);
        assert!(config.clean);
        assert_eq!(
            config.backend,
            BuildBackend::Cuda {
                archs: vec!["sm_86"]
            }
        );
    }

    #[test]
    fn build_config_targets_isolated_prism_source_when_selected() {
        let mut app = App::default();
        app.state.build.build_flavor = lmml_compat::LlamaRuntimeFlavor::Prism;
        app.state.build.prism.source_dir = PathBuf::from("/tmp/lmml-prism");
        app.state.build.prism.backend = "Cuda".to_string();
        app.state.build.prism.archs = vec!["sm_120".to_string()];

        let config = app.build_config(false);

        assert_eq!(config.flavor, lmml_compat::LlamaRuntimeFlavor::Prism);
        assert_eq!(config.source_dir, PathBuf::from("/tmp/lmml-prism"));
        assert_eq!(
            config.git_ref.as_deref(),
            lmml_compat::LlamaRuntimeFlavor::Prism.initial_ref()
        );
        assert_eq!(
            config.backend,
            BuildBackend::Cuda {
                archs: vec!["sm_120"]
            }
        );
    }

    #[test]
    fn completed_prism_build_does_not_replace_upstream_identity() {
        let mut app = App::default();
        let upstream_binary = app.state.build.binary.clone();
        let binary = PathBuf::from("/tmp/lmml-prism/build/bin/llama-server");
        app.handle_event(AppEvent::BuildEvent(BuildEvent::Completed {
            binary: binary.clone(),
            elapsed: std::time::Duration::from_secs(1),
            fingerprint: Box::new(lmml_build::BuildFingerprint {
                flavor: lmml_compat::LlamaRuntimeFlavor::Prism,
                source_url: lmml_compat::LlamaRuntimeFlavor::Prism
                    .repository_url()
                    .to_string(),
                commit: "prism-commit".to_string(),
                cmake_hash: [7; 32],
                binary: binary.clone(),
            }),
            backend: BuildBackend::Cuda {
                archs: vec!["sm_120"],
            },
            archs: vec!["sm_120".to_string()],
            sccache_used: true,
            verification: Box::new(lmml_build::RuntimeVerification {
                version: lmml_build::RUNTIME_VERIFICATION_VERSION,
                prism_tensor_types: vec![142, 143],
                rocm_targets: Vec::new(),
                cuda_targets: vec!["sm_120".to_string()],
                server_sha256: "a".repeat(64),
                hip_library: None,
                hip_library_sha256: None,
                cuda_library: Some(PathBuf::from("/tmp/libggml-cuda.so")),
                cuda_library_sha256: Some("b".repeat(64)),
            }),
        }));

        assert_eq!(app.state.build.binary, upstream_binary);
        assert_eq!(app.state.build.prism.binary, binary);
        assert_eq!(app.state.build.prism.commit, "prism-commit");
        assert_eq!(app.state.build.prism.archs, vec!["sm_120"]);
        assert!(app.state.build.prism.sccache_used);
        assert!(!app.state.build.prism.last_verified.is_empty());
        assert_eq!(
            app.state.build.prism.verification_version,
            lmml_build::RUNTIME_VERIFICATION_VERSION
        );
        assert_eq!(
            app.state.build.prism.verified_prism_tensor_types,
            vec![142, 143]
        );
        assert_eq!(app.state.build.prism.verified_server_sha256, "a".repeat(64));
        assert_eq!(app.state.build.prism.verified_cuda_targets, vec!["sm_120"]);
        assert_eq!(
            app.state.build.prism.verified_cuda_library,
            PathBuf::from("/tmp/libggml-cuda.so")
        );
    }

    #[test]
    fn prism_build_start_and_failure_invalidate_artifact_attestation() {
        let mut app = App::default();
        app.state.build.prism.verification_version = lmml_build::RUNTIME_VERIFICATION_VERSION;
        app.state.build.prism.verified_prism_tensor_types = vec![142, 143];
        app.state.build.prism.verified_server_sha256 = "a".repeat(64);
        app.state.build.prism.verified_hip_library = PathBuf::from("/tmp/libggml-hip.so");
        app.state.build.prism.verified_hip_library_sha256 = "b".repeat(64);
        app.state.build.prism.verified_cuda_targets = vec!["sm_120".to_string()];
        app.state.build.prism.verified_cuda_library = PathBuf::from("/tmp/libggml-cuda.so");
        app.state.build.prism.verified_cuda_library_sha256 = "c".repeat(64);
        app.state.build.build_flavor = lmml_compat::LlamaRuntimeFlavor::Prism;

        app.dispatch(Action::StartBuild);
        assert_eq!(app.state.build.prism.verification_version, 0);
        assert!(app.state.build.prism.verified_server_sha256.is_empty());

        app.state.build.prism.verified_server_sha256 = "stale".to_string();
        app.handle_event(AppEvent::BuildEvent(BuildEvent::Started {
            flavor: lmml_compat::LlamaRuntimeFlavor::Prism,
        }));
        assert_eq!(app.state.build.prism.verification_version, 0);
        assert!(app.state.build.prism.verified_server_sha256.is_empty());
        assert!(app
            .state
            .build
            .prism
            .verified_hip_library
            .as_os_str()
            .is_empty());
        assert!(app.state.build.prism.verified_cuda_targets.is_empty());
        assert!(app
            .state
            .build
            .prism
            .verified_cuda_library
            .as_os_str()
            .is_empty());

        app.state.build.prism.verified_server_sha256 = "stale".to_string();
        app.handle_event(AppEvent::BuildEvent(BuildEvent::Failed {
            last_error: "compile failed".to_string(),
            log_tail: Vec::new(),
        }));
        assert!(app.state.build.prism.verified_server_sha256.is_empty());
    }

    #[test]
    fn build_config_auto_uses_detection_but_explicit_backend_wins() {
        let mut app = App::default();
        app.detect_profile = Some(cuda_profile());

        app.state.build.backend = "Auto".to_string();
        let config = app.build_config(false);
        assert_eq!(
            config.backend,
            BuildBackend::Cuda {
                archs: vec!["sm_86"]
            }
        );

        app.state.build.backend = "CpuFallback".to_string();
        let config = app.build_config(false);
        assert_eq!(config.backend, BuildBackend::CpuFallback);
    }

    #[test]
    fn build_config_uses_rocm_targets_and_tool_paths() {
        let mut app = App::default();
        let mut profile = cuda_profile();
        profile.cuda = lmml_detect::CudaCompatibility::NoGpu;
        profile.gpus.clear();
        profile.rocm = lmml_detect::RocmSupport {
            available: true,
            hip_clang_path: Some(PathBuf::from("/opt/rocm/llvm/bin/clang")),
            hip_path: Some(PathBuf::from("/opt/rocm")),
            targets: vec!["gfx1100".to_string()],
            ..lmml_detect::RocmSupport::default()
        };
        app.detect_profile = Some(profile);
        app.state.build.backend = "Auto".to_string();

        let config = app.build_config(false);

        assert_eq!(
            config.backend,
            BuildBackend::Rocm {
                targets: vec!["gfx1100".to_string()],
            }
        );
        assert_eq!(
            config.rocm_hipcxx,
            Some(PathBuf::from("/opt/rocm/llvm/bin/clang"))
        );
        assert_eq!(config.rocm_hip_path, Some(PathBuf::from("/opt/rocm")));

        app.state.build.backend = "Rocm".to_string();
        app.state.build.archs = vec!["gfx1030".to_string()];
        let config = app.build_config(false);

        assert_eq!(
            config.backend,
            BuildBackend::Rocm {
                targets: vec!["gfx1100".to_string()],
            }
        );
    }

    #[test]
    fn rocm_detection_change_invalidates_prism_attestation() {
        let mut app = App::default();
        app.state.build.build_flavor = lmml_compat::LlamaRuntimeFlavor::Prism;
        app.state.build.prism.backend = "Rocm".to_string();
        app.state.build.prism.archs = vec!["gfx1100".to_string()];
        app.state.build.prism.cmake_hash = "old".to_string();
        app.state.build.prism.last_verified = "old".to_string();
        app.state.build.prism.verification_version = lmml_build::RUNTIME_VERIFICATION_VERSION;
        app.state.build.prism.verified_prism_tensor_types = vec![142, 143];
        app.state.build.prism.verified_rocm_targets = vec!["gfx1100".to_string()];
        app.state.build.prism.verified_server_sha256 = "a".repeat(64);
        app.state.build.prism.verified_hip_library = PathBuf::from("/tmp/libggml-hip.so");
        app.state.build.prism.verified_hip_library_sha256 = "b".repeat(64);
        let mut profile = cuda_profile();
        profile.cuda = lmml_detect::CudaCompatibility::NoGpu;
        profile.gpus.clear();
        profile.rocm = lmml_detect::RocmSupport {
            available: true,
            targets: vec!["gfx1201".to_string()],
            ..lmml_detect::RocmSupport::default()
        };

        app.handle_event(AppEvent::DetectComplete(Box::new(profile)));

        assert_eq!(app.state.build.prism.archs, vec!["gfx1201"]);
        assert!(app.state.build.prism.cmake_hash.is_empty());
        assert_eq!(app.state.build.prism.verification_version, 0);
        assert!(app.state.build.prism.verified_prism_tensor_types.is_empty());
        assert!(app.state.build.prism.verified_rocm_targets.is_empty());
        assert!(app.state.build.prism.verified_server_sha256.is_empty());
        assert!(app
            .state
            .build
            .prism
            .verified_hip_library
            .as_os_str()
            .is_empty());
        assert!(app.state.build.prism.verified_hip_library_sha256.is_empty());
    }

    #[test]
    fn startup_completion_clears_detect_and_scan_in_flight_state() {
        let mut app = App::default();
        let tempdir = tempfile::tempdir().expect("tempdir");
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.detect_running = true;
        app.model_scan_running = true;

        app.handle_event(AppEvent::DetectComplete(Box::new(cuda_profile())));
        assert!(!app.detect_running);
        assert!(app.detect_profile.is_some());

        app.handle_event(AppEvent::ModelScanComplete(vec![model_entry(
            "startup.gguf",
        )]));
        assert!(!app.model_scan_running);
        assert_eq!(app.models.len(), 1);
    }

    #[test]
    fn first_run_enter_starts_build_and_esc_dismisses() {
        let mut app = App::new_with_state_and_first_run(PersistentState::default(), true);
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Enter)));
        assert_eq!(action, Some(Action::RunDetect));
        app.handle_event(AppEvent::DetectComplete(Box::new(SystemProfile {
            compiler: None,
            cmake: None,
            git: None,
            cuda: lmml_detect::CudaCompatibility::NoGpu,
            rocm: lmml_detect::RocmSupport::default(),
            gpus: Vec::new(),
            gpu_probe_error: None,
            nvidia_devices: lmml_detect::NvidiaDeviceNodes::default(),
            sccache: None,
            metal: lmml_detect::MetalSupport {
                available: false,
                displays: Vec::new(),
            },
            vulkan: lmml_detect::VulkanSupport {
                available: false,
                devices: Vec::new(),
            },
            cpu: lmml_detect::CpuFeatures {
                model: String::new(),
                cores: 1,
                threads: 1,
                avx: false,
                avx2: false,
                avx512: false,
                neon: false,
                features: Vec::new(),
            },
            memory: lmml_detect::MemInfo {
                total_mb: 1024,
                available_mb: 512,
            },
            disk: lmml_detect::DiskInfo {
                available_bytes: 8 * 1024 * 1024 * 1024,
                path: PathBuf::from("."),
            },
        })));
        assert_eq!(app.onboarding_step, OnboardingStep::HardwareSummary);
        assert!(app.first_run_onboarding);

        let mut app = App::new_with_state_and_first_run(PersistentState::default(), true);
        assert_eq!(
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Esc))),
            None
        );
        assert!(!app.first_run_onboarding);
    }

    #[test]
    fn model_scan_and_selection_update_state() {
        let mut app = App::default();
        app.handle_event(AppEvent::ModelScanComplete(vec![
            model_entry("a.gguf"),
            model_entry("b.gguf"),
        ]));
        assert_eq!(app.models.len(), 2);
        app.active_tab = Tab::Models;
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Down)));
        assert_eq!(app.selected_model, 1);
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Enter)));
        assert_eq!(action, Some(Action::SelectModel(PathBuf::from("b.gguf"))));
    }

    #[test]
    fn hf_results_and_download_progress_update_state() {
        let mut app = App::default();
        app.handle_event(AppEvent::HfSearchResults(vec![HfModelResult {
            repo_id: "org/model".to_string(),
            filename: "model-Q4_K_M.gguf".to_string(),
            size_bytes: 10,
            downloads: 5,
            url: "https://example.test/model-Q4_K_M.gguf".to_string(),
        }]));
        assert_eq!(app.hf_results.len(), 1);
        app.active_tab = Tab::Models;
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('D'))));
        assert!(matches!(action, Some(Action::DownloadModel(_))));

        app.handle_event(AppEvent::DownloadProgress(DownloadProgress {
            bytes_received: 5,
            total_bytes: Some(10),
            resumed_from: 2,
        }));
        assert_eq!(
            app.download_progress
                .as_ref()
                .map(|progress| progress.resumed_from),
            Some(2)
        );
    }

    #[test]
    fn alias_modal_collects_path_and_delete_requires_confirmation() {
        let mut app = App::default();
        app.active_tab = Tab::Models;

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('a'))));
        assert_eq!(action, Some(Action::AddModelAlias));
        app.dispatch(action.expect("alias action"));
        assert!(matches!(app.active_modal, Some(Modal::AddAlias { .. })));

        for value in "/tmp/model.gguf".chars() {
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char(value))));
        }
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Enter)));
        assert_eq!(
            action,
            Some(Action::ConfirmAddModelAlias(PathBuf::from(
                "/tmp/model.gguf"
            )))
        );

        app.models = vec![model_entry("delete-me.gguf")];
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('x'))));
        assert!(matches!(action, Some(Action::DeleteModel(_))));
        app.dispatch(action.expect("delete action"));
        assert!(matches!(
            app.active_modal,
            Some(Modal::ConfirmDelete { .. })
        ));
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('y'))));
        assert!(matches!(action, Some(Action::ConfirmDeleteModel(_))));
    }

    #[test]
    fn hf_search_modal_builds_filtered_query() {
        let mut app = App::default();
        app.active_tab = Tab::Models;
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('/'))));
        assert_eq!(action, Some(Action::OpenHfSearch));
        app.dispatch(action.expect("open hf search"));

        for _ in 0.."gguf".len() {
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Backspace)));
        }
        for value in "mistral".chars() {
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char(value))));
        }
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Tab)));
        for value in "mistral".chars() {
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char(value))));
        }
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Tab)));
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('4'))));

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Enter)));
        assert_eq!(
            action,
            Some(Action::SearchHf(HfSearchQuery {
                keywords: "mistral".to_string(),
                architecture: Some("mistral".to_string()),
                quant_filter: Some(QuantTier::Q4),
                max_results: 20,
            }))
        );
    }

    #[test]
    fn server_config_auto_ngl_uses_detected_vram_fit() {
        let mut app = App::default();
        app.detect_profile = Some(SystemProfile {
            compiler: None,
            cmake: None,
            git: None,
            cuda: lmml_detect::CudaCompatibility::NoGpu,
            rocm: lmml_detect::RocmSupport::default(),
            gpus: vec![lmml_detect::GpuInfo {
                name: "RTX".to_string(),
                memory_total_mb: 8_192,
                compute_cap: "8.6".to_string(),
                arch: Some("sm_86"),
            }],
            gpu_probe_error: None,
            nvidia_devices: lmml_detect::NvidiaDeviceNodes::default(),
            sccache: None,
            metal: lmml_detect::MetalSupport {
                available: false,
                displays: Vec::new(),
            },
            vulkan: lmml_detect::VulkanSupport {
                available: false,
                devices: Vec::new(),
            },
            cpu: lmml_detect::CpuFeatures {
                model: String::new(),
                cores: 4,
                threads: 8,
                avx: false,
                avx2: false,
                avx512: false,
                neon: false,
                features: Vec::new(),
            },
            memory: lmml_detect::MemInfo {
                total_mb: 16,
                available_mb: 8,
            },
            disk: lmml_detect::DiskInfo {
                available_bytes: 8,
                path: PathBuf::from("."),
            },
        });
        let model = ModelEntry {
            size_bytes: 1024 * 1024 * 1024,
            ..model_entry("small.gguf")
        };

        assert_eq!(app.server_config(&model).n_gpu_layers, -1);
    }

    #[test]
    fn server_config_auto_ngl_uses_live_rocm_vram_fit() {
        let mut app = App::default();
        let mut profile = cuda_profile();
        profile.cuda = lmml_detect::CudaCompatibility::NoGpu;
        profile.gpus.clear();
        profile.rocm = lmml_detect::RocmSupport {
            available: true,
            targets: vec!["gfx1201".to_string()],
            devices: vec![lmml_detect::RocmGpuInfo {
                name: "AMD Radeon AI PRO R9700".to_string(),
                target: Some("gfx1201".to_string()),
                vram: Some(lmml_detect::GpuVramInfo {
                    total_mb: 32_624,
                    used_mb: 2_931,
                    free_mb: 29_693,
                }),
            }],
            ..lmml_detect::RocmSupport::default()
        };
        app.detect_profile = Some(profile);
        let model = ModelEntry {
            size_bytes: 10 * 1024 * 1024 * 1024,
            quant: "Q8_0".to_string(),
            ..model_entry("Qwen3.5-9B-Q8_0.gguf")
        };

        assert_eq!(app.server_config(&model).n_gpu_layers, -1);
        assert_eq!(app.server_gpu_layers_label(Some(&model)), "auto -> -1");
    }

    #[test]
    fn server_config_auto_ngl_uses_cached_rocm_vram_fit() {
        let mut app = App::default();
        app.state.system_profile = Some(lmml_state::SystemProfile {
            cuda_toolkit: None,
            gpu_names: vec!["AMD Radeon AI PRO R9700".to_string()],
            gpu_archs: Vec::new(),
            rocm_available: true,
            rocm_targets: vec!["gfx1201".to_string()],
            vram_mb: vec![32_624],
            sccache: true,
        });
        let model = ModelEntry {
            size_bytes: 10 * 1024 * 1024 * 1024,
            quant: "Q8_0".to_string(),
            ..model_entry("Qwen3.5-9B-Q8_0.gguf")
        };

        assert_eq!(app.server_config(&model).n_gpu_layers, -1);
        assert_eq!(
            app.server_gpu_layers_label(Some(&model)),
            "auto -> -1 (cached VRAM)"
        );
    }

    #[test]
    fn model_vram_fit_uses_cached_rocm_vram() {
        let mut app = App::default();
        app.state.system_profile = Some(lmml_state::SystemProfile {
            cuda_toolkit: None,
            gpu_names: vec!["AMD Radeon AI PRO R9700".to_string()],
            gpu_archs: Vec::new(),
            rocm_available: true,
            rocm_targets: vec!["gfx1201".to_string()],
            vram_mb: vec![32_624],
            sccache: true,
        });
        let model = ModelEntry {
            size_bytes: 10 * 1024 * 1024 * 1024,
            quant: "Q8_0".to_string(),
            ..model_entry("Qwen3.5-9B-Q8_0.gguf")
        };

        assert!(matches!(
            app.model_vram_fit(&model),
            lmml_models::VramFit::Full { .. }
        ));
        assert_eq!(app.model_recommended_ngl(&model), -1);
    }

    #[test]
    fn server_config_auto_ngl_preserves_llama_auto_without_probe_data() {
        let app = App::default();
        let model = ModelEntry {
            size_bytes: 10 * 1024 * 1024 * 1024,
            quant: "Q8_0".to_string(),
            ..model_entry("Qwen3.5-9B-Q8_0.gguf")
        };

        assert_eq!(app.server_config(&model).n_gpu_layers, -1);
        assert_eq!(app.server_gpu_layers_label(Some(&model)), "auto -> -1");
    }

    #[test]
    fn prism_model_without_profile_preserves_configured_context() {
        let mut app = App::default();
        app.state.server.ctx_size = 196_608;
        app.state.server.flash_attn = false;
        app.state.server.jinja = false;
        app.state.server.extra_args = vec!["--parallel".to_string(), "4".to_string()];
        let model = ModelEntry {
            runtime: lmml_models::GgufRuntimeRequirement::Prism,
            tensor_types: std::collections::BTreeSet::from([142]),
            ..model_entry("TERNARY-BONSAI-2-27B-DERISKED.gguf")
        };

        let config = app.server_config(&model);

        assert_eq!(config.ctx_size, 196_608);
        assert!(config.flash_attn);
        assert!(config.jinja);
        assert!(config
            .extra_args
            .windows(2)
            .any(|pair| pair == ["--parallel", "1"]));
        assert!(config
            .extra_args
            .windows(2)
            .any(|pair| pair == ["--temp", "1.0"]));
        assert!(config
            .extra_args
            .windows(2)
            .any(|pair| pair == ["--top-p", "0.95"]));
        assert!(config
            .extra_args
            .windows(2)
            .any(|pair| pair == ["--top-k", "20"]));
    }

    #[test]
    fn server_config_uses_matching_model_runtime_profile() {
        let mut app = App::default();
        app.state.server.chat_template = "/templates/global-qwen.jinja".to_string();
        app.state.server.jinja = true;
        app.state.model.profiles = vec![lmml_state::ModelRuntimeProfile {
            name: "nemotron-native".to_string(),
            model: PathBuf::from("Nemotron3-Nano-4B-Q8_K_P.gguf"),
            server: lmml_state::ServerConfig {
                port: 1200,
                host: "127.0.0.1".to_string(),
                ctx_size: 262_144,
                n_gpu_layers: -1,
                batch_size: 512,
                ubatch_size: 128,
                threads: 8,
                flash_attn: false,
                mlock: false,
                api_key: String::new(),
                jinja: true,
                chat_template: String::new(),
                extra_args: vec!["--parallel".to_string(), "1".to_string()],
            },
        }];

        let config = app.server_config(&model_entry(
            "/home/angelo/.local/share/lmml/models/Nemotron3-Nano-4B-Q8_K_P.gguf",
        ));

        assert_eq!(config.chat_template, None);
        assert!(config.jinja);
        assert_eq!(config.ctx_size, 262_144);
        assert_eq!(config.extra_args, vec!["--parallel", "1"]);
    }

    #[test]
    fn qwen36_custom_config_adds_reasoning_none_and_q8_kv() {
        let mut app = App::default();
        app.state.server.ctx_size = 131_072;
        app.state.server.extra_args = vec!["--parallel".to_string(), "1".to_string()];
        let model = model_entry("/models/Qwen3.6-35B-A3B-Q4_K_M.gguf");

        let config = app.server_config(&model);

        assert!(config
            .extra_args
            .windows(2)
            .any(|window| window == ["--reasoning-format", "none"]));
        assert!(config
            .extra_args
            .windows(2)
            .any(|window| window == ["-ctk", "q8_0"]));
        assert!(config
            .extra_args
            .windows(2)
            .any(|window| window == ["-ctv", "q8_0"]));
    }

    #[test]
    fn qwen_safeguards_preserve_existing_kv_cache_types() {
        let mut app = App::default();
        app.state.server.ctx_size = 131_072;
        app.state.server.extra_args = vec![
            "--parallel".to_string(),
            "4".to_string(),
            "-ctk".to_string(),
            "q4_0".to_string(),
            "-ctv".to_string(),
            "q4_0".to_string(),
        ];
        let model = model_entry("/models/Qwen3.6-27B-Q4_K_M.gguf");

        let config = app.server_config(&model);

        assert!(config
            .extra_args
            .windows(2)
            .any(|window| window == ["--reasoning-format", "none"]));
        assert_eq!(
            config
                .extra_args
                .iter()
                .filter(|arg| *arg == "-ctk" || *arg == "--cache-type-k")
                .count(),
            1
        );
        assert!(config
            .extra_args
            .windows(2)
            .any(|window| window == ["-ctk", "q4_0"]));
        assert!(config
            .extra_args
            .windows(2)
            .any(|window| window == ["-ctv", "q4_0"]));
    }

    #[test]
    fn selecting_model_applies_runtime_profile_to_visible_settings() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let mut app = App::default();
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.state.server.chat_template = "/templates/qwen.jinja".to_string();
        app.state.model.profiles = vec![lmml_state::ModelRuntimeProfile {
            name: "nemotron-native".to_string(),
            model: PathBuf::from("Nemotron3-Nano-4B-Q8_K_P.gguf"),
            server: lmml_state::ServerConfig {
                chat_template: String::new(),
                jinja: true,
                ctx_size: 262_144,
                ubatch_size: 128,
                ..lmml_state::ServerConfig::default()
            },
        }];

        app.dispatch(Action::SelectModel(PathBuf::from(
            "/models/Nemotron3-Nano-4B-Q8_K_P.gguf",
        )));

        assert_eq!(
            app.state.model.last_used,
            PathBuf::from("/models/Nemotron3-Nano-4B-Q8_K_P.gguf")
        );
        assert!(app.state.server.chat_template.is_empty());
        assert!(app.state.server.jinja);
        assert_eq!(app.state.server.ctx_size, 262_144);
        assert_eq!(
            app.status_message,
            "Model selected; runtime profile applied"
        );
    }

    #[test]
    fn profile_key_cycles_qwen_runtime_profiles_from_models_tab() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let mut app = App::default();
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.active_tab = Tab::Models;
        app.models = vec![model_entry(
            "/home/angelo/.local/share/lmml/models/Qwen3.5-4B-Q8_0.gguf",
        )];
        app.selected_model = 0;

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        assert!(matches!(action, Some(Action::CycleRuntimeProfile(_))));
        app.dispatch(action.expect("profile cycle action"));

        assert_eq!(app.state.model.active_profile, "orion-qwen-q8-balanced");
        assert_eq!(app.state.server.ctx_size, 262_144);
        assert_eq!(app.state.server.ubatch_size, 128);
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "2"]);
        assert_eq!(app.status_message, "Profile orion-qwen-q8-balanced applied");
    }

    #[test]
    fn runtime_policy_key_cycles_and_persists_selection() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let state_path = tempdir.path().join("state.toml");
        let mut app = App::default();
        app.state_save_path = Some(state_path.clone());

        for expected in [
            lmml_state::RuntimeSelectionMode::Upstream,
            lmml_state::RuntimeSelectionMode::Prism,
            lmml_state::RuntimeSelectionMode::Auto,
        ] {
            let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('v'))));
            assert_eq!(action, Some(Action::CycleRuntimeSelection));
            app.dispatch(action.expect("runtime selection action"));
            assert_eq!(app.state.build.runtime_selection, expected);
        }

        let saved = lmml_state::AppState::load_from_path(state_path).expect("saved state");
        assert_eq!(
            saved.build.runtime_selection,
            lmml_state::RuntimeSelectionMode::Auto
        );
    }

    #[test]
    fn qwen9b_m6000_profiles_are_available_from_tui_profile_switcher() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let mut app = App::default();
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.active_tab = Tab::Models;
        app.models = vec![model_entry(
            "/home/angelo/.local/share/lmml/models/Qwen3.5-9B-Q8_0.gguf",
        )];
        app.selected_model = 0;

        app.dispatch(Action::SelectModel(app.models[0].path.clone()));

        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-deep");
        assert_eq!(app.state.server.ctx_size, 262_144);
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "1"]);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        assert!(matches!(action, Some(Action::CycleRuntimeProfile(_))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-fanout1");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "2"]);
        assert_eq!(app.state.server.ubatch_size, 128);
        assert!(!app.state.server.flash_attn);
        assert_eq!(&app.state.server.extra_args[8..10], ["--cache-ram", "4096"]);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-fanout2");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "2"]);
        assert_eq!(app.state.server.ubatch_size, 128);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-fanout3");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "3"]);
        assert_eq!(app.state.server.ubatch_size, 128);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-fanout4");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "4"]);
        assert_eq!(app.state.server.ubatch_size, 128);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-fanout6");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "6"]);
        assert_eq!(app.state.server.ubatch_size, 96);
        assert_eq!(&app.state.server.extra_args[8..10], ["--cache-ram", "8192"]);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-mtp-deep");
        assert_eq!(
            &app.state.server.extra_args[10..12],
            ["--spec-type", "draft-mtp"]
        );
        assert!(!app
            .state
            .server
            .extra_args
            .iter()
            .any(|arg| arg == "--mmproj"));

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-mtp-vision");
        assert_eq!(
            &app.state.server.extra_args[10..12],
            ["--spec-type", "draft-mtp"]
        );
        assert!(app
            .state
            .server
            .extra_args
            .iter()
            .any(|arg| arg == "--mmproj"));

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-kvu-fanout4");
        assert_eq!(app.state.server.ctx_size, 86_016);
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "4"]);
        assert_eq!(
            &app.state.server.extra_args[4..8],
            ["-ctk", "q4_0", "-ctv", "q4_0"]
        );
        assert!(app
            .state
            .server
            .extra_args
            .iter()
            .any(|arg| arg == "--kv-unified"));

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-kvu-fanout6");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "6"]);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "m6000-qwen9b-kvu-fanout8");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "8"]);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "5060ti-qwen9b-deep");
        assert_eq!(app.state.server.ctx_size, 196_608);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "5060ti-qwen9b-balanced2");
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "2"]);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "5060ti-qwen9b-kvu-fanout4");
        assert_eq!(app.state.server.ctx_size, 73_728);

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "5060ti-qwen9b-kvu-fanout6");

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "5060ti-qwen9b-kvu-fanout8");

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(app.state.model.active_profile, "5070ti-qwen9b-deep");
    }

    #[test]
    fn gemma4_mtp_profile_is_available_from_tui_profile_switcher() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let mut app = App::default();
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.active_tab = Tab::Models;
        app.models = vec![model_entry("/custom/models/Gemma4-12B-QAT-Q4_K_M.gguf")];
        app.selected_model = 0;

        app.dispatch(Action::SelectModel(app.models[0].path.clone()));

        assert_eq!(app.state.model.active_profile, "gemma4-12b-mtp-q4km");
        assert_eq!(app.state.server.ctx_size, 73_728);
        assert_eq!(app.state.server.n_gpu_layers, 99);
        assert!(app.state.server.flash_attn);
        assert_eq!(
            &app.state.server.extra_args[4..8],
            [
                "-md",
                app.state.server.extra_args[5].as_str(),
                "--spec-type",
                "draft-mtp"
            ]
        );
        assert_eq!(
            app.state.server.extra_args[5],
            "/custom/models/mtp-gemma-4-12B-it.gguf"
        );
        assert_eq!(
            &app.state.server.extra_args[8..],
            [
                "--temp",
                "0.6",
                "--top-k",
                "64",
                "--top-p",
                "0.9",
                "--min-p",
                "0.05",
                "--repeat-penalty",
                "1.1"
            ]
        );

        let launch_config = app.server_config(&app.models[0]);
        assert_eq!(
            launch_config.extra_args[5],
            "/custom/models/mtp-gemma-4-12B-it.gguf"
        );
    }

    #[test]
    fn r9700_crown11_qwen_profile_applies_to_selected_model() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let mut app = App::default();
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.active_tab = Tab::Models;
        app.models = vec![model_entry(
            "/home/angelo/.local/share/lmml/models/qwen35-crown11-aw-Q8_0.gguf",
        )];
        app.selected_model = 0;

        app.dispatch(Action::SelectModel(app.models[0].path.clone()));

        assert_eq!(
            app.state.model.active_profile,
            "r9700-qwen35-crown11-aw-q8-balanced2"
        );
        assert_eq!(app.state.server.ctx_size, 262_144);
        assert_eq!(app.state.server.n_gpu_layers, -1);
        assert_eq!(app.state.server.ubatch_size, 128);
        assert_eq!(app.state.server.threads, 8);
        assert!(app.state.server.flash_attn);
        assert!(app.state.server.jinja);
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "2"]);
        assert_eq!(
            &app.state.server.extra_args[4..],
            ["-ctk", "q8_0", "-ctv", "q8_0", "--cache-ram", "4096"]
        );

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        app.dispatch(action.expect("profile cycle action"));
        assert_eq!(
            app.state.model.active_profile,
            "r9700-qwen35-crown11-aw-q8-deep"
        );
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "1"]);
    }

    #[test]
    fn r9700_qwen35_27b_q6_profile_applies_to_selected_model() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let mut app = App::default();
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.active_tab = Tab::Models;
        app.models = vec![model_entry("/models/Qwen3.5-27B-Q6_K.gguf")];
        app.selected_model = 0;

        app.dispatch(Action::SelectModel(app.models[0].path.clone()));

        assert_eq!(app.state.model.active_profile, "r9700-qwen35-27b-q6-deep");
        assert_eq!(app.state.server.ctx_size, 262_144);
        assert_eq!(app.state.server.n_gpu_layers, -1);
        assert_eq!(app.state.server.ubatch_size, 128);
        assert!(app.state.server.flash_attn);
        assert!(app.state.server.jinja);
        assert_eq!(&app.state.server.extra_args[0..2], ["--parallel", "1"]);
        assert_eq!(
            &app.state.server.extra_args[4..],
            ["-ctk", "q8_0", "-ctv", "q8_0", "--cache-ram", "4096"]
        );
    }

    #[test]
    fn profile_key_warns_when_switching_while_server_is_running() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let mut app = App::default();
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.active_tab = Tab::Server;
        app.state.model.last_used =
            PathBuf::from("/home/angelo/.local/share/lmml/models/Qwen3.5-4B-Q8_0.gguf");
        app.server_status = ServerStatus::Ready {
            url: "http://127.0.0.1:1200".to_string(),
        };

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p'))));
        assert!(matches!(action, Some(Action::CycleRuntimeProfile(_))));
        app.dispatch(action.expect("profile cycle action"));

        assert_eq!(app.state.model.active_profile, "orion-qwen-q8-balanced");
        assert_eq!(
            app.status_message,
            "Profile orion-qwen-q8-balanced; restart server to apply"
        );
    }

    #[test]
    fn cuda_legacy_arch_detection_matches_pascal_and_maxwell() {
        assert!(cuda_backend_targets_legacy_archs(&BuildBackend::Cuda {
            archs: vec!["sm_52", "sm_61"],
        }));
        assert!(!cuda_backend_targets_legacy_archs(&BuildBackend::Cuda {
            archs: vec!["sm_86"],
        }));
        assert!(!cuda_backend_targets_legacy_archs(&BuildBackend::Cuda {
            archs: vec!["sm_120a"],
        }));
        assert!(!cuda_backend_targets_legacy_archs(&BuildBackend::Cuda {
            archs: Vec::new(),
        }));
    }

    #[test]
    fn cuda13_dropped_arch_detection_matches_pascal_not_turing() {
        let pascal = BuildBackend::Cuda {
            archs: vec!["sm_61"],
        };
        let turing = BuildBackend::Cuda {
            archs: vec!["sm_75"],
        };
        let ampere = BuildBackend::Cuda {
            archs: vec!["sm_86"],
        };

        assert!(cuda_backend_targets_archs_dropped_by_cuda13(&pascal));
        assert!(!cuda_backend_targets_archs_dropped_by_cuda13(&turing));
        assert!(!cuda_backend_targets_archs_dropped_by_cuda13(&ampere));
        assert!(cuda_backend_dropped_by_toolkit_version(
            &pascal,
            "Cuda compilation tools, release 13.1, V13.1.48"
        ));
        assert!(!cuda_backend_dropped_by_toolkit_version(
            &pascal,
            "Cuda compilation tools, release 12.4, V12.4.131"
        ));
    }

    #[test]
    fn cuda_legacy_compiler_selection_rejects_cuda_13() {
        assert!(cuda_major_works_for_legacy_archs(
            "Cuda compilation tools, release 11.8, V11.8.89"
        ));
        assert!(cuda_major_works_for_legacy_archs(
            "Cuda compilation tools, release 12.4, V12.4.131"
        ));
        assert!(!cuda_major_works_for_legacy_archs(
            "Cuda compilation tools, release 13.1, V13.1.48"
        ));
    }

    #[test]
    fn cuda_glibc_compat_shim_matches_cuda_13() {
        assert!(cuda_glibc_compat_shim_needed_for_version(
            "Cuda compilation tools, release 13.1, V13.1.48"
        ));
        assert!(!cuda_glibc_compat_shim_needed_for_version(
            "Cuda compilation tools, release 12.4, V12.4.131"
        ));
    }

    #[test]
    fn cuda_host_compiler_policy_matches_cuda_versions() {
        assert_eq!(
            cuda_host_compiler_majors_for_versions(
                "Cuda compilation tools, release 13.1, V13.1.48",
                "15.2.0\n"
            ),
            Some(vec![14, 13, 12, 11])
        );
        assert_eq!(
            cuda_host_compiler_majors_for_versions(
                "Cuda compilation tools, release 11.8, V11.8.89",
                "13.3.0\n"
            ),
            Some(vec![11, 10, 9])
        );
        assert_eq!(
            cuda_host_compiler_majors_for_versions(
                "Cuda compilation tools, release 12.4, V12.4.131",
                "15.2.0\n"
            ),
            None
        );
    }

    #[test]
    fn server_key_toggles_start_and_stop() {
        let mut app = App::default();
        app.active_tab = Tab::Server;
        assert_eq!(
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('s')))),
            Some(Action::StartServer)
        );
        app.server_status = ServerStatus::Ready {
            url: "http://127.0.0.1:8080".to_string(),
        };
        assert_eq!(
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('s')))),
            Some(Action::StopServer)
        );
    }

    #[test]
    fn server_model_swap_updates_selection_when_stopped() {
        let mut app = App::default();
        let tempdir = tempfile::tempdir().expect("tempdir");
        app.state_save_path = Some(tempdir.path().join("state.toml"));
        app.active_tab = Tab::Server;
        app.models = vec![model_entry("a.gguf"), model_entry("b.gguf")];
        app.selected_model = 0;

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('m'))));

        assert_eq!(action, None);
        assert_eq!(app.selected_model, 1);
        assert_eq!(app.state.model.last_used, PathBuf::from("b.gguf"));
        assert!(app.active_modal.is_none());
    }

    #[test]
    fn server_model_swap_running_cancel_keeps_selection() {
        let mut app = App::default();
        app.active_tab = Tab::Server;
        app.models = vec![model_entry("a.gguf"), model_entry("b.gguf")];
        app.selected_model = 0;
        app.state.model.last_used = PathBuf::from("a.gguf");
        app.server_status = ServerStatus::Ready {
            url: "http://127.0.0.1:8080".to_string(),
        };

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('m'))));

        assert_eq!(action, None);
        assert_eq!(app.selected_model, 0);
        assert_eq!(app.state.model.last_used, PathBuf::from("a.gguf"));
        assert!(matches!(
            app.active_modal,
            Some(Modal::ConfirmModelSwap { .. })
        ));

        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Esc)));
        assert_eq!(action, None);
        assert!(app.active_modal.is_none());
        assert_eq!(app.selected_model, 0);
        assert_eq!(app.state.model.last_used, PathBuf::from("a.gguf"));
    }

    #[test]
    fn server_model_swap_running_confirm_emits_restart_action() {
        let mut app = App::default();
        app.active_tab = Tab::Server;
        app.models = vec![model_entry("a.gguf"), model_entry("b.gguf")];
        app.selected_model = 0;
        app.state.model.last_used = PathBuf::from("a.gguf");
        app.server_status = ServerStatus::Ready {
            url: "http://127.0.0.1:8080".to_string(),
        };

        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('m'))));
        let action = app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('y'))));

        assert_eq!(
            action,
            Some(Action::ConfirmModelSwap(model_entry("b.gguf")))
        );
        assert_eq!(app.state.model.last_used, PathBuf::from("a.gguf"));
    }

    #[test]
    fn settings_modal_edits_and_toggles_server_config() {
        let mut app = App::default();
        app.active_tab = Tab::Settings;
        app.selected_settings_field = SettingsField::Port;

        assert_eq!(
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('e')))),
            None
        );
        assert_eq!(app.settings_edit_buffer.as_deref(), Some("8080"));
        for key in [
            KeyCode::Backspace,
            KeyCode::Backspace,
            KeyCode::Backspace,
            KeyCode::Backspace,
            KeyCode::Char('1'),
            KeyCode::Char('2'),
            KeyCode::Char('0'),
            KeyCode::Char('0'),
        ] {
            app.handle_event(AppEvent::Key(KeyEvent::from(key)));
        }
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Enter)));
        assert_eq!(app.state.server.port, 1200);
        assert_eq!(app.active_tab, Tab::Settings);
        assert!(app.settings_edit_buffer.is_none());

        app.selected_settings_field = SettingsField::FlashAttn;
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char(' '))));
        assert!(!app.state.server.flash_attn);
    }

    #[test]
    fn settings_probe_key_and_unsupported_warnings_work() {
        let mut app = App::default();
        app.active_tab = Tab::Settings;
        assert_eq!(
            app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Char('p')))),
            Some(Action::ProbeServerCapabilities)
        );

        app.state.server.flash_attn = true;
        app.state.server.api_key = "secret".to_string();
        app.handle_event(AppEvent::ServerCapabilities(Ok(LlamaBinaryCapabilities {
            version: Some("test".to_string()),
            flash_attn: false,
            flash_attn_requires_value: false,
            mlock: true,
            api_key: false,
            ubatch_size: true,
            chat_template: true,
            jinja: true,
            reranking: false,
            flags: vec!["--model".to_string(), "--port".to_string()],
        })));
        assert_eq!(
            app.server_compat_warnings(),
            vec![
                "--flash-attn not available in this llama-server build".to_string(),
                "--api-key not available in this llama-server build".to_string(),
            ]
        );
    }

    #[test]
    fn significant_events_persist_and_reload_state() {
        let tempdir = tempfile::tempdir().expect("tempdir");
        let state_path = tempdir.path().join("state.toml");
        let mut app = App::default();
        app.state_save_path = Some(state_path.clone());
        app.active_tab = Tab::Models;

        let model_path = tempdir.path().join("model.gguf");
        app.handle_event(AppEvent::DownloadComplete(Ok(ModelEntry {
            path: model_path.clone(),
            name: "model".to_string(),
            size_bytes: 4,
            quant: "Q4".to_string(),
            context_length: None,
            architecture: None,
            aliased: false,
            runtime: lmml_models::GgufRuntimeRequirement::Upstream,
            tensor_types: std::collections::BTreeSet::new(),
            prism_metadata_keys: std::collections::BTreeSet::new(),
        })));
        app.active_tab = Tab::Settings;
        app.selected_settings_field = SettingsField::Port;
        app.settings_edit_buffer = Some("9091".to_string());
        app.handle_event(AppEvent::Key(KeyEvent::from(KeyCode::Enter)));
        app.dispatch(Action::Quit);

        let reloaded =
            PersistentState::load_from_path(&state_path).expect("reload persisted state");
        assert_eq!(reloaded.model.last_used, model_path);
        assert_eq!(reloaded.server.port, 9091);
    }

    fn model_entry(path: &str) -> ModelEntry {
        ModelEntry {
            path: PathBuf::from(path),
            name: path.to_string(),
            size_bytes: 1024,
            quant: "Q4_K_M".to_string(),
            context_length: Some(4096),
            architecture: Some("llama".to_string()),
            aliased: false,
            runtime: lmml_models::GgufRuntimeRequirement::Upstream,
            tensor_types: std::collections::BTreeSet::new(),
            prism_metadata_keys: std::collections::BTreeSet::new(),
        }
    }

    fn cuda_profile() -> SystemProfile {
        SystemProfile {
            compiler: None,
            cmake: None,
            git: None,
            cuda: lmml_detect::CudaCompatibility::Compatible {
                archs: vec!["sm_86"],
            },
            rocm: lmml_detect::RocmSupport::default(),
            gpus: vec![lmml_detect::GpuInfo {
                name: "RTX".to_string(),
                memory_total_mb: 8_192,
                compute_cap: "8.6".to_string(),
                arch: Some("sm_86"),
            }],
            gpu_probe_error: None,
            nvidia_devices: lmml_detect::NvidiaDeviceNodes::default(),
            sccache: None,
            metal: lmml_detect::MetalSupport {
                available: false,
                displays: Vec::new(),
            },
            vulkan: lmml_detect::VulkanSupport {
                available: false,
                devices: Vec::new(),
            },
            cpu: lmml_detect::CpuFeatures {
                model: String::new(),
                cores: 4,
                threads: 8,
                avx: false,
                avx2: false,
                avx512: false,
                neon: false,
                features: Vec::new(),
            },
            memory: lmml_detect::MemInfo {
                total_mb: 16,
                available_mb: 8,
            },
            disk: lmml_detect::DiskInfo {
                available_bytes: 8,
                path: PathBuf::from("."),
            },
        }
    }
}
