//! Shared HTTP API contracts for lmml nodes.
//!
//! This crate contains dependency-light serde DTOs used by the future
//! headless `lmml-node` binary, LMML TUI cluster views, and external clients
//! such as AgentQ. It intentionally avoids server, process, and AgentQ packet
//! logic so the contracts can remain stable across runtime implementations.
//!
//! # Example
//!
//! ```rust
//! use lmml_api::{InferRequest, TaskType};
//!
//! let request = InferRequest::new("Explain the current node status.");
//! assert_eq!(request.task_type, TaskType::General);
//! ```

use std::collections::BTreeMap;
use std::time::{SystemTime, UNIX_EPOCH};

use base64::engine::general_purpose::URL_SAFE_NO_PAD;
use base64::Engine;
use ring::signature;
use serde::{Deserialize, Serialize};
use serde_json::Value;

/// Current version string for the LMML node HTTP API.
pub const API_VERSION: &str = "lmml-node-api/v1";

/// Header used by clients to pass an idempotent request identifier.
pub const HEADER_REQUEST_ID: &str = "x-lmml-request-id";

/// Header used by nodes to identify the worker handling a response.
pub const HEADER_NODE_ID: &str = "x-lmml-node-id";

/// Header used by enforced nodes to prove that their inference upstream is an
/// approved LMML gateway rather than a raw llama-server endpoint.
pub const HEADER_APPROVED_UPSTREAM: &str = "x-lmml-approved-upstream";

/// Signed, short-lived proof that an upstream is the admitted LMML gateway.
pub const HEADER_GATEWAY_ATTESTATION: &str = "x-lmml-gateway-attestation";

/// Claims signed by the gateway attestation key.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GatewayAttestationClaims {
    /// Contract version.
    pub schema_version: u32,
    /// Stable gateway identity.
    pub gateway_id: String,
    /// Deployment hash currently loaded by the gateway.
    pub deployment_hash: String,
    /// Approval receipt identity and sequence.
    pub receipt_id: String,
    /// Approval receipt sequence.
    pub receipt_sequence: u64,
    /// Revocation epoch observed when the proof was issued.
    pub revocation_epoch: u64,
    /// Unix seconds when the proof was issued.
    pub issued_at_unix: i64,
    /// Unix seconds after which the proof is invalid.
    pub expires_at_unix: i64,
}

/// Wire representation of a signed gateway attestation.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GatewayAttestation {
    /// Signed claims.
    pub claims: GatewayAttestationClaims,
    /// Ed25519 signature encoded as lowercase hexadecimal.
    pub signature_hex: String,
}

/// Expected approval context used to bind a gateway proof to one deployment.
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct GatewayAttestationBinding {
    /// Expected gateway identity.
    pub gateway_id: String,
    /// Expected deployment hash.
    pub deployment_hash: String,
    /// Expected receipt identity.
    pub receipt_id: String,
    /// Expected receipt sequence.
    pub receipt_sequence: u64,
    /// Expected revocation epoch.
    pub revocation_epoch: u64,
}

/// Sign gateway claims with an operator-provisioned Ed25519 PKCS#8 key.
pub fn sign_gateway_attestation(
    claims: GatewayAttestationClaims,
    pkcs8_key: &[u8],
) -> Result<String, String> {
    let key = ring::signature::Ed25519KeyPair::from_pkcs8(pkcs8_key)
        .map_err(|_| "invalid gateway attestation private key".to_string())?;
    let payload = serde_json::to_vec(&claims).map_err(|error| error.to_string())?;
    let signature_hex = hex_encode(key.sign(&payload).as_ref());
    let attestation = GatewayAttestation {
        claims,
        signature_hex,
    };
    let bytes = serde_json::to_vec(&attestation).map_err(|error| error.to_string())?;
    Ok(URL_SAFE_NO_PAD.encode(bytes))
}

/// Verify and decode a gateway attestation, including its expiry window.
pub fn verify_gateway_attestation(
    encoded: &str,
    public_key: &[u8],
    now_unix: i64,
) -> Result<GatewayAttestation, String> {
    let bytes = URL_SAFE_NO_PAD
        .decode(encoded)
        .map_err(|_| "invalid gateway attestation encoding".to_string())?;
    let attestation: GatewayAttestation = serde_json::from_slice(&bytes)
        .map_err(|_| "invalid gateway attestation JSON".to_string())?;
    if attestation.claims.schema_version != 1
        || attestation.claims.expires_at_unix <= now_unix
        || attestation.claims.issued_at_unix > now_unix + 5
        || attestation.claims.issued_at_unix >= attestation.claims.expires_at_unix
    {
        return Err("gateway attestation is expired or invalid".to_string());
    }
    let signature_bytes = hex_decode(&attestation.signature_hex)
        .ok_or_else(|| "invalid gateway attestation signature".to_string())?;
    let public = signature::UnparsedPublicKey::new(&signature::ED25519, public_key);
    let payload = serde_json::to_vec(&attestation.claims).map_err(|error| error.to_string())?;
    public
        .verify(&payload, &signature_bytes)
        .map_err(|_| "gateway attestation signature verification failed".to_string())?;
    Ok(attestation)
}

/// Verify that signed claims belong to the expected approved deployment.
pub fn validate_gateway_attestation_binding(
    claims: &GatewayAttestationClaims,
    expected: &GatewayAttestationBinding,
) -> Result<(), String> {
    if claims.gateway_id != expected.gateway_id
        || claims.deployment_hash != expected.deployment_hash
        || claims.receipt_id != expected.receipt_id
        || claims.receipt_sequence != expected.receipt_sequence
        || claims.revocation_epoch != expected.revocation_epoch
    {
        return Err("gateway attestation claims do not match the approved deployment".into());
    }
    Ok(())
}

fn hex_encode(bytes: &[u8]) -> String {
    bytes.iter().map(|byte| format!("{byte:02x}")).collect()
}

fn hex_decode(value: &str) -> Option<Vec<u8>> {
    if !value.len().is_multiple_of(2) {
        return None;
    }
    (0..value.len())
        .step_by(2)
        .map(|index| u8::from_str_radix(&value[index..index + 2], 16).ok())
        .collect()
}

/// Return current Unix seconds for gateway attestation issuance.
pub fn unix_now() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|duration| duration.as_secs() as i64)
        .unwrap_or_default()
}

/// Default IPv4 multicast endpoint for LAN node advertisements.
pub const LAN_DISCOVERY_MULTICAST_ADDR: &str = "239.77.77.11:8177";

/// Magic marker used to identify LMML LAN advertisements.
pub const LAN_DISCOVERY_MAGIC: &str = "lmml.node.advertisement";

/// Current version of the LMML LAN advertisement payload.
pub const LAN_DISCOVERY_VERSION: u16 = 1;

/// Default interval between node LAN advertisements in milliseconds.
pub const LAN_DISCOVERY_DEFAULT_INTERVAL_MS: u64 = 5_000;

/// Default router expiry window for discovered nodes in milliseconds.
pub const LAN_DISCOVERY_DEFAULT_TTL_MS: u64 = 30_000;

/// Maximum UDP payload size accepted for LMML LAN advertisements.
pub const MAX_LAN_ADVERTISEMENT_BYTES: usize = 60 * 1024;

/// Hardware or runtime backend used by a node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum BackendKind {
    /// NVIDIA CUDA backend.
    Cuda,
    /// Apple Metal backend.
    Metal,
    /// AMD ROCm/HIP backend.
    Hip,
    /// Vulkan backend, often useful as a broad GPU fallback.
    Vulkan,
    /// CPU backend with AVX2 acceleration.
    CpuAvx2,
    /// CPU backend with AVX acceleration.
    CpuAvx,
    /// Portable CPU fallback backend.
    CpuFallback,
    /// Backend is not known or has not been detected.
    Unknown,
}

/// Operational role advertised by an LMML node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NodeRole {
    /// Operator workstation with the primary local GPU.
    WorkstationMainGpu,
    /// General LAN worker.
    LanWorker,
    /// Batch evaluator for offline or background work.
    BatchEvaluator,
    /// Embedding-specialized worker.
    EmbeddingWorker,
    /// Critic or review worker.
    CriticWorker,
    /// Router or coordinator node.
    Router,
    /// Node that also hosts the LMML TUI.
    TuiHost,
    /// Role is not known.
    Unknown,
}

/// Privacy tier declared by a node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum PrivacyTier {
    /// Node should only receive LAN-local traffic.
    LanOnly,
    /// Node should only receive localhost traffic.
    LocalhostOnly,
    /// Node may call or receive internet-routed work.
    InternetAllowed,
}

/// Runtime health state for a node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum NodeStatus {
    /// Node and local model runtime are ready.
    Ready,
    /// Node is reachable but one or more dependencies are degraded.
    Degraded,
    /// Node is starting a local dependency.
    Starting,
    /// Node is intentionally stopped.
    Stopped,
    /// Node is in an error state.
    Error,
}

/// GPU information advertised by a node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct GpuDescriptor {
    /// Human-readable GPU name.
    pub name: String,
    /// Backend used for this GPU.
    pub backend: BackendKind,
    /// Optional architecture string, such as `sm_86` or `gfx1030`.
    pub arch: Option<String>,
    /// Total VRAM in MiB.
    pub vram_total_mb: u64,
    /// Free VRAM in MiB when the node can report it.
    pub vram_free_mb: Option<u64>,
}

/// Model metadata advertised by a node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ModelDescriptor {
    /// Stable model identifier used in requests.
    pub id: String,
    /// Human-readable model name.
    pub name: String,
    /// Optional local path. Public LAN responses may omit this.
    pub path: Option<String>,
    /// Model architecture, such as `llama` or `qwen`.
    pub architecture: Option<String>,
    /// Quantization string, such as `Q4_K_M`.
    pub quantization: Option<String>,
    /// Context length in tokens.
    pub context_length: Option<u32>,
    /// Model size in bytes.
    pub size_bytes: Option<u64>,
    /// Whether the model is currently loaded by the local runtime.
    pub loaded: bool,
    /// Alternate names accepted by this node.
    pub aliases: Vec<String>,
}

/// AgentQ-related capabilities advertised by an LMML node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct AgentQDescriptor {
    /// Whether AgentQ bridge behavior is enabled.
    pub enabled: bool,
    /// AgentQ bridge API version.
    pub api_version: String,
    /// AgentQ node name advertised by this LMML worker.
    pub node_name: String,
    /// AgentQ node kind, kept as a string to avoid coupling to AgentQ crates.
    pub node_kind: String,
    /// Optional CROWN cell role.
    pub crown_cell: Option<String>,
    /// Packet overhead in bytes when binary AgentQ packet routes are enabled.
    pub packet_overhead_bytes: Option<usize>,
    /// AgentQ-related endpoints exposed by the node.
    pub endpoints: Vec<String>,
    /// Tags useful for AgentQ routing.
    pub tags: Vec<String>,
}

/// Static and semi-static capabilities advertised by an LMML node.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct NodeCapabilities {
    /// LMML node HTTP API version.
    pub api_version: String,
    /// LMML binary or crate version.
    pub lmml_version: String,
    /// Node identifier.
    pub node_id: String,
    /// Human-readable node name.
    pub node_name: String,
    /// Public URL clients should use, if advertised.
    pub public_url: Option<String>,
    /// Roles this node can serve.
    pub roles: Vec<NodeRole>,
    /// Free-form tags used for routing.
    pub tags: Vec<String>,
    /// Node privacy tier.
    pub privacy: PrivacyTier,
    /// Primary backend.
    pub backend: BackendKind,
    /// GPU descriptors.
    pub gpus: Vec<GpuDescriptor>,
    /// Models known to this node.
    pub models: Vec<ModelDescriptor>,
    /// Maximum context length among known models.
    pub max_context_tokens: Option<u32>,
    /// True when `/v1/infer` is supported.
    pub supports_infer: bool,
    /// True when `/v1/chat/completions` proxy compatibility is supported.
    pub supports_chat_completions: bool,
    /// True when `/v1/responses` proxy compatibility is supported.
    #[serde(default)]
    pub supports_responses: bool,
    /// True when `/v1/messages` Anthropic Messages compatibility is supported.
    #[serde(default)]
    pub supports_anthropic_messages: bool,
    /// True when `/v1/embeddings` proxy compatibility is supported.
    pub supports_embeddings: bool,
    /// True when server lifecycle control is enabled.
    pub supports_server_control: bool,
    /// Whether API authentication is required for protected routes.
    pub auth_required: bool,
    /// llama.cpp commit used to build the local runtime, when known.
    pub llama_cpp_commit: Option<String>,
    /// Optional AgentQ bridge descriptor.
    pub agentq: Option<AgentQDescriptor>,
    /// Extension map for non-breaking additions.
    pub extra: BTreeMap<String, Value>,
}

/// UDP multicast advertisement emitted by `lmml-node` for LAN discovery.
///
/// Routers use this payload only as a discovery hint. A node is not routable
/// until the router verifies the advertised URL with authenticated
/// `/v1/health`, `/v1/capabilities`, and `/v1/load` probes.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LanNodeAdvertisement {
    /// Magic marker used to reject unrelated UDP payloads.
    pub magic: String,
    /// Advertisement wire format version.
    pub version: u16,
    /// LMML node HTTP API version.
    pub api_version: String,
    /// Node identifier.
    pub node_id: String,
    /// Human-readable node name.
    pub node_name: String,
    /// Public base URL the router should probe, for example `http://host:8101`.
    pub public_url: String,
    /// Primary backend.
    pub backend: BackendKind,
    /// GPU descriptors.
    pub gpus: Vec<GpuDescriptor>,
    /// Models known to this node.
    pub models: Vec<ModelDescriptor>,
    /// Whether protected node routes require bearer authentication.
    pub auth_required: bool,
    /// Roles this node can serve.
    pub roles: Vec<NodeRole>,
    /// Free-form tags used for routing.
    pub tags: Vec<String>,
    /// UTC time when the node emitted this advertisement.
    pub last_seen_utc: String,
}

impl LanNodeAdvertisement {
    /// Return true when this payload is for the current LMML discovery format.
    pub fn is_current_lmml_advertisement(&self) -> bool {
        self.magic == LAN_DISCOVERY_MAGIC
            && self.version == LAN_DISCOVERY_VERSION
            && self.api_version == API_VERSION
    }
}

/// Health response returned by `GET /v1/health`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct HealthResponse {
    /// LMML node HTTP API version.
    pub api_version: String,
    /// Node identifier.
    pub node_id: String,
    /// Human-readable node name.
    pub node_name: String,
    /// Current node status.
    pub status: NodeStatus,
    /// Current UTC time as an RFC 3339 string.
    pub time_utc: String,
    /// Node process uptime in seconds.
    pub uptime_s: u64,
    /// Whether the local llama.cpp server is healthy.
    pub llama_healthy: bool,
    /// Active model, when known.
    pub active_model: Option<ModelDescriptor>,
    /// Optional human-readable status message.
    pub message: Option<String>,
}

/// Load and request counters returned by `GET /v1/load`.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct LoadResponse {
    /// Node identifier.
    pub node_id: String,
    /// Current node status.
    pub status: NodeStatus,
    /// CPU utilization percentage.
    pub cpu_usage_pct: f32,
    /// Total system memory in MiB.
    pub memory_total_mb: u64,
    /// Used system memory in MiB.
    pub memory_used_mb: u64,
    /// Current GPU descriptors.
    pub gpus: Vec<GpuDescriptor>,
    /// Number of currently running requests.
    pub running_requests: u32,
    /// Number of completed requests since process start.
    pub completed_requests: u64,
    /// Number of failed requests since process start.
    pub failed_requests: u64,
    /// Total input tokens processed since process start.
    pub tokens_in_total: u64,
    /// Total output tokens produced since process start.
    pub tokens_out_total: u64,
}

/// Inference task type used for scheduling and prompt shaping.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum TaskType {
    /// General inference.
    General,
    /// Planning work.
    Planning,
    /// Coding work.
    Coding,
    /// Critique or review work.
    Critique,
    /// Browser or navigation work.
    Browser,
    /// Research work.
    Research,
    /// Embedding generation.
    Embedding,
    /// Reranking work.
    Rerank,
    /// Summarization work.
    Summarization,
    /// JSON-constrained generation.
    Json,
    /// Batch evaluation.
    BatchEval,
}

/// Stable LMML-native inference request.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InferRequest {
    /// Optional request ID supplied by the caller.
    pub request_id: Option<String>,
    /// Optional higher-level task ID.
    pub task_id: Option<String>,
    /// Optional agent or caller ID.
    pub agent_id: Option<String>,
    /// Scheduling or prompt-shaping task type.
    pub task_type: TaskType,
    /// Optional requested model ID.
    pub model: Option<String>,
    /// Optional system prompt.
    pub system: Option<String>,
    /// User prompt.
    pub prompt: String,
    /// Maximum output tokens.
    pub max_tokens: Option<u32>,
    /// Sampling temperature.
    pub temperature: Option<f32>,
    /// Nucleus sampling probability.
    pub top_p: Option<f32>,
    /// Optional deterministic seed.
    pub seed: Option<i64>,
    /// Optional stop strings.
    pub stop: Option<Vec<String>>,
    /// Optional response format hint, such as `json`.
    pub response_format: Option<String>,
    /// Extension metadata for routers and agents.
    pub metadata: BTreeMap<String, Value>,
}

impl InferRequest {
    /// Create a general inference request with conservative defaults.
    pub fn new(prompt: impl Into<String>) -> Self {
        Self {
            prompt: prompt.into(),
            ..Self::default()
        }
    }
}

impl Default for InferRequest {
    fn default() -> Self {
        Self {
            request_id: None,
            task_id: None,
            agent_id: None,
            task_type: TaskType::General,
            model: None,
            system: None,
            prompt: String::new(),
            max_tokens: Some(1024),
            temperature: Some(0.2),
            top_p: Some(0.95),
            seed: None,
            stop: None,
            response_format: None,
            metadata: BTreeMap::new(),
        }
    }
}

/// Stable LMML-native inference response.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct InferResponse {
    /// Request ID from the caller or assigned by the node.
    pub request_id: String,
    /// Node that handled the request.
    pub node_id: String,
    /// Model used for generation.
    pub model: Option<String>,
    /// Generated text.
    pub output: String,
    /// Raw upstream response, when proxying preserves it.
    pub raw: Option<Value>,
    /// End-to-end request latency in milliseconds.
    pub latency_ms: u64,
    /// Input token count when reported by the upstream runtime.
    pub tokens_in: Option<u64>,
    /// Output token count when reported by the upstream runtime.
    pub tokens_out: Option<u64>,
    /// Finish reason when reported by the upstream runtime.
    pub finish_reason: Option<String>,
}

/// Embedding request accepted by LMML nodes.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct EmbeddingRequest {
    /// Optional request ID supplied by the caller.
    pub request_id: Option<String>,
    /// Input strings to embed.
    pub input: Vec<String>,
    /// Optional requested model ID.
    pub model: Option<String>,
    /// Optional encoding format hint.
    pub encoding_format: Option<String>,
}

/// Embedding response returned by LMML nodes.
#[derive(Debug, Clone, PartialEq, Serialize, Deserialize)]
pub struct EmbeddingResponse {
    /// Request ID from the caller or assigned by the node.
    pub request_id: String,
    /// Node that handled the request.
    pub node_id: String,
    /// Raw upstream embedding payload.
    pub raw: Value,
    /// End-to-end request latency in milliseconds.
    pub latency_ms: u64,
}

/// Server lifecycle action requested from a node.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
#[serde(rename_all = "snake_case")]
pub enum ServerAction {
    /// Start the managed local server.
    Start,
    /// Stop the managed local server.
    Stop,
    /// Restart the managed local server.
    Restart,
    /// Return current managed server status.
    Status,
}

/// Request body for `POST /v1/server/control`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ServerControlRequest {
    /// Requested lifecycle action.
    pub action: ServerAction,
}

/// Response body for `POST /v1/server/control`.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ServerControlResponse {
    /// Node that handled the control request.
    pub node_id: String,
    /// Node status after the action.
    pub status: NodeStatus,
    /// Human-readable action result.
    pub message: String,
}

/// Top-level error response returned by LMML node APIs.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ErrorResponse {
    /// Structured error body.
    pub error: ApiErrorBody,
}

/// Structured error body returned by LMML node APIs.
#[derive(Debug, Clone, PartialEq, Eq, Serialize, Deserialize)]
pub struct ApiErrorBody {
    /// Stable machine-readable error code.
    pub code: String,
    /// Human-readable error message.
    pub message: String,
    /// Request ID related to the failure, when known.
    pub request_id: Option<String>,
    /// Optional additional structured details.
    pub details: Option<BTreeMap<String, String>>,
}

#[cfg(test)]
mod tests {
    use super::*;
    use pretty_assertions::assert_eq;
    use ring::signature::KeyPair;
    use serde_json::json;

    #[test]
    fn infer_request_round_trips_with_request_id() {
        let mut request = InferRequest::new("say ok");
        request.request_id = Some("req-1".to_string());
        request.task_type = TaskType::Critique;
        request
            .metadata
            .insert("privacy".to_string(), json!("lan_only"));

        let text = serde_json::to_string(&request).expect("serialize infer request");
        let decoded: InferRequest = serde_json::from_str(&text).expect("deserialize infer request");

        assert_eq!(decoded, request);
        assert_eq!(decoded.request_id.as_deref(), Some("req-1"));
    }

    #[test]
    fn capabilities_include_version_and_auth_fields() {
        let capabilities = NodeCapabilities {
            api_version: API_VERSION.to_string(),
            lmml_version: "0.1.0".to_string(),
            node_id: "node-a".to_string(),
            node_name: "Node A".to_string(),
            public_url: Some("http://127.0.0.1:8101".to_string()),
            roles: vec![NodeRole::LanWorker],
            tags: vec!["lmml".to_string()],
            privacy: PrivacyTier::LocalhostOnly,
            backend: BackendKind::CpuFallback,
            gpus: Vec::new(),
            models: Vec::new(),
            max_context_tokens: None,
            supports_infer: true,
            supports_chat_completions: false,
            supports_responses: true,
            supports_anthropic_messages: true,
            supports_embeddings: false,
            supports_server_control: false,
            auth_required: true,
            llama_cpp_commit: Some("abc123".to_string()),
            agentq: None,
            extra: BTreeMap::new(),
        };

        let value = serde_json::to_value(&capabilities).expect("serialize capabilities");

        assert_eq!(value["api_version"], API_VERSION);
        assert_eq!(value["lmml_version"], "0.1.0");
        assert_eq!(value["llama_cpp_commit"], "abc123");
        assert_eq!(value["auth_required"], true);
        assert_eq!(value["supports_anthropic_messages"], true);
        assert_eq!(value["supports_responses"], true);
    }

    #[test]
    fn lan_advertisement_round_trips() {
        let advertisement = LanNodeAdvertisement {
            magic: LAN_DISCOVERY_MAGIC.to_string(),
            version: LAN_DISCOVERY_VERSION,
            api_version: API_VERSION.to_string(),
            node_id: "node-a".to_string(),
            node_name: "Node A".to_string(),
            public_url: "http://192.168.1.12:8101".to_string(),
            backend: BackendKind::Cuda,
            gpus: Vec::new(),
            models: Vec::new(),
            auth_required: true,
            roles: vec![NodeRole::LanWorker],
            tags: vec!["lmml".to_string()],
            last_seen_utc: "2026-07-20T00:00:00Z".to_string(),
        };

        let text = serde_json::to_string(&advertisement).expect("serialize advertisement");
        let decoded: LanNodeAdvertisement =
            serde_json::from_str(&text).expect("deserialize advertisement");

        assert_eq!(decoded, advertisement);
        assert!(decoded.is_current_lmml_advertisement());
    }

    #[test]
    fn server_control_request_uses_snake_case_action() {
        let request = ServerControlRequest {
            action: ServerAction::Restart,
        };

        let value = serde_json::to_value(request).expect("serialize control request");

        assert_eq!(value, json!({ "action": "restart" }));
    }

    #[test]
    fn error_response_round_trips() {
        let response = ErrorResponse {
            error: ApiErrorBody {
                code: "bad_request".to_string(),
                message: "prompt is empty".to_string(),
                request_id: Some("req-2".to_string()),
                details: None,
            },
        };

        let text = serde_json::to_string(&response).expect("serialize error response");
        let decoded: ErrorResponse =
            serde_json::from_str(&text).expect("deserialize error response");

        assert_eq!(decoded, response);
    }

    #[test]
    fn gateway_attestation_is_signed_and_expires() {
        let rng = ring::rand::SystemRandom::new();
        let key = ring::signature::Ed25519KeyPair::generate_pkcs8(&rng).expect("generate key");
        let pair = ring::signature::Ed25519KeyPair::from_pkcs8(key.as_ref()).expect("parse key");
        let claims = GatewayAttestationClaims {
            schema_version: 1,
            gateway_id: "gateway-a".into(),
            deployment_hash: "sha256:deployment".into(),
            receipt_id: "receipt-a".into(),
            receipt_sequence: 4,
            revocation_epoch: 2,
            issued_at_unix: 100,
            expires_at_unix: 130,
        };
        let encoded = sign_gateway_attestation(claims.clone(), key.as_ref()).expect("sign");
        let verified =
            verify_gateway_attestation(&encoded, pair.public_key().as_ref(), 110).expect("verify");
        assert_eq!(verified.claims, claims);
        validate_gateway_attestation_binding(
            &verified.claims,
            &GatewayAttestationBinding {
                gateway_id: "gateway-a".into(),
                deployment_hash: "sha256:deployment".into(),
                receipt_id: "receipt-a".into(),
                receipt_sequence: 4,
                revocation_epoch: 2,
            },
        )
        .expect("binding");
        let mut mismatched = verified.claims.clone();
        mismatched.deployment_hash = "sha256:other".into();
        assert!(validate_gateway_attestation_binding(
            &mismatched,
            &GatewayAttestationBinding {
                gateway_id: "gateway-a".into(),
                deployment_hash: "sha256:deployment".into(),
                receipt_id: "receipt-a".into(),
                receipt_sequence: 4,
                revocation_epoch: 2,
            },
        )
        .is_err());
        assert!(verify_gateway_attestation(&encoded, pair.public_key().as_ref(), 130).is_err());
    }
}
