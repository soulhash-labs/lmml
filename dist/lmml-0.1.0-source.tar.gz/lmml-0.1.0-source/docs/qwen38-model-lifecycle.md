# Qwen3.8 Model Lifecycle

LMML treats `/home/angelo/repos/qwen38-safetensors/` as the canonical Qwen3.8
substrate. The directory must contain the complete checkpoint before import;
Hugging Face partial-download cache files are not model shards.

## Import and verify

```sh
LMML_DATA_HOME="${XDG_DATA_HOME:-$HOME/.local/share}"

lmml model import /home/angelo/repos/qwen38-safetensors \
  --lineage-id qwen38-27b
lmml model inspect "$LMML_DATA_HOME/lmml/models/manifests/qwen38-27b.json"
lmml model verify /home/angelo/repos/qwen38-safetensors \
  --manifest "$LMML_DATA_HOME/lmml/models/manifests/qwen38-27b.json"
lmml model lineage "$LMML_DATA_HOME/lmml/models/manifests/qwen38-27b.json"
```

The importer reads `config.json`, tokenizer/generation/processor assets, the
Safetensors index, every referenced shard, and each shard header. It records
SHA-256 digests, tensor names, dtypes, shapes, parameter count, data layout,
and the architecture fields present in the checkpoint. Index and header tensor
sets must agree exactly, and tensor offsets must cover the complete shard
payload without gaps, overlap, truncation, or trailing data.

Schema version 2 records each behavioral auxiliary asset separately and uses
validated SHA-256 values. During a full import, progress is emitted to stderr
after every hashed weight shard; JSON output on stdout remains machine-readable.
Schema-v1 manifests must be re-imported to a new managed record rather than
edited in place.

Managed lineage registration is immutable. Re-importing identical content is
idempotent, while different content under an existing lineage ID is rejected.
Successor imports require an explicit parent:

```sh
lmml model import /models/qwen38-successor-1 \
  --lineage-id qwen38-successor-1 \
  --parent qwen38-27b
```

The persisted manifest is the source record for later derivatives. A GGUF
file has a separate `ArtifactIdentity` and must point back to the Qwen3.8
`ModelIdentity`; quantization never replaces the Safetensors identity.

## GGUF derivation

Derivation verifies the canonical source before invoking llama.cpp. It runs the
converter and quantizer asynchronously with streamed output, writes to unique
temporary files, inspects GGUF metadata, asks `llama-server` to open and serve
the artifact, refuses to overwrite an output, hashes the result, and appends a
source-artifact anchor plus the derived artifact under the managed data
directory.

```sh
lmml model derive \
  --manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --source /home/angelo/repos/qwen38-safetensors \
  --output ~/.local/share/lmml/models/artifacts/gguf/qwen38-27b-q8_0.gguf \
  --artifact-id qwen38-27b-q8_0 \
  --quant q8-0
```

When the inference GPU is reserved, conversion can stop at an immutable pending
candidate. This performs source verification, conversion, quantization, GGUF
metadata inspection, SHA-256 hashing, and no-clobber publication without loading
the model or adding it to the runnable artifact catalog:

```sh
lmml model derive \
  --manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --source /home/angelo/repos/qwen38-safetensors \
  --output ~/.local/share/lmml/models/candidates/qwen38-27b-bf16.gguf \
  --artifact-id qwen38-27b-bf16 \
  --quant bf16 \
  --defer-admission
```

After the GPU is available, admit that exact candidate. LMML re-hashes the
payload, verifies its canonical source, runs the tensor/backend checks, and only
then creates the runnable artifact record:

```sh
lmml model admit-artifact \
  --candidate ~/.local/share/lmml/models/candidates/qwen38-27b-bf16.json \
  --manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --source /home/angelo/repos/qwen38-safetensors
```

Before backend admission, revalidate the canonical source, candidate hash, and
GGUF metadata without starting `llama-server`:

```sh
lmml model verify-candidate \
  --candidate ~/.local/share/lmml/models/candidates/qwen38-27b-bf16.json \
  --candidate ~/.local/share/lmml/models/candidates/qwen38-27b-q8_0.json \
  --candidate ~/.local/share/lmml/models/candidates/qwen38-27b-q6_k.json \
  --candidate ~/.local/share/lmml/models/candidates/qwen38-27b-q4_k_m.json \
  --manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --source /home/angelo/repos/qwen38-safetensors \
  --json
```

Success reports `verified_pending_backend_admission`; a batch shares one
canonical-source verification pass while hashing every GGUF before and after
metadata inspection. It does not make a GGUF runnable or add it to the admitted
artifact DAG.

The 2026-09-23 verification pass established the following pending artifact
evidence without starting a backend:

| Candidate | SHA-256 | GGUF file type |
| --- | --- | ---: |
| BF16 | `cf3123616fbf0178a3abe3b58a438ca6d0e0088c19e0cafe57009408a496d86e` | 32 |
| Q8_0 | `f60d5f08ef1524a8aee53f02aa9c19d47b276524de004440dcb3c613bfafcb7a` | 7 |
| Q6_K | `15bba9deafd3454e5f48b7c2829e6715fa3c966d6297985ccb30444c675367ad` | 18 |
| Q4_K_M | `9d02bb6e73b840330600e6839f6dc32a1fb0df4c01665bdee567c7781717e9c8` | 15 |

All four files report GGUF v3, architecture `qwen35`, 65 blocks, 866 tensors,
an embedding width of 5,120, and a context limit of 262,144. Backend tensor
checks and runnable artifact admission remain pending until model loading is
permitted.

F16/BF16 conversion requires the llama.cpp converter and its Python
dependencies. Q8_0, Q6_K, and Q4_K_M additionally require `llama-quantize`.
LMML reports missing tools or unsupported conversion failures without
registering an artifact.

When the host does not provide the validated ROCm Python/Torch environment,
use the explicit full-model container executor. It does not install Torch into
the host environment; the image must contain Python, Torch, and the llama.cpp
converter dependencies:

```sh
lmml model derive \
  --manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --source /home/angelo/repos/qwen38-safetensors \
  --output ~/.local/share/lmml/models/artifacts/gguf/qwen38-27b-f16.gguf \
  --artifact-id qwen38-27b-f16 \
  --quant f16 \
  --rocm-container /usr/bin/docker
```

The default image is AMD's validated
`rocm/pytorch:rocm7.2.4_ubuntu24.04_py3.12_pytorch_release_2.9.1` image. Override
it with `--rocm-image` only when another image has been validated. Before LMML
hashes the substrate or starts conversion, it verifies that the image imports
Torch, NumPy, Safetensors, Transformers, and llama.cpp's GGUF Python module. Provenance records
the container runtime version, image ID/digest, Python/Torch/ROCm package
versions, and the host-mounted converter Git revision.

Conversion does not receive `/dev/kfd` or `/dev/dri`; GGUF conversion is a CPU
operation and must not contend with an active GPU workload. The container mounts
the canonical source read-only and can write only inside a private temporary
derivation directory.
An immediately admitted GGUF is published only after metadata inspection,
`llama-server --check-tensors` admission, and the 600-second large-model startup
window. The probe also requires `/v1/models` to identify the exact candidate,
so an unrelated service cannot satisfy admission through a temporary-port race.
Admission forces `-ngl 0`, so this integrity check cannot claim or contend with
an accelerator that is running another workload. It still loads the model and
must only run when the operator permits that load. A deferred candidate is
published under the candidate boundary and cannot enter runtime selection
before `model admit-artifact` completes.

List the append-only artifact catalog with:

```sh
lmml model artifacts --lineage-id qwen38-27b --json
```

Artifact records include the exact absolute payload path, SHA-256, conversion
provenance, parent artifact, and backend admission evidence. A GGUF without
admission evidence cannot enter the catalog or runtime selection.

## Pristine baseline

LMML ships a deterministic prompt set at
`docs/fixtures/qwen38-baseline-prompts.json`:

```json
[
  {"case_id":"identity","prompt":"State your model family in one sentence."},
  {"case_id":"arithmetic","prompt":"Return only the result of 37 * 19."}
]
```

Then bind the baseline to one exact admitted artifact:

```sh
lmml model baseline \
  --artifact-id qwen38-27b-q8_0 \
  --baseline-id pristine-v1 \
  --prompts docs/fixtures/qwen38-baseline-prompts.json \
  --predict 32 \
  --gpu-layers -1
```

LMML records the artifact and backend hashes, fixed sampling parameters, prompts,
captured outputs, and per-output SHA-256 values. Use `--gpu-layers 0` for a CPU
baseline. Baseline execution loads the model; do not run it while the selected
device is reserved for another workload.

## Runtime boundary

llama.cpp remains LMML's deployment backend. Register an already-running local
process against its admitted artifact, then request a capability lease:

```sh
lmml runtime register \
  --runtime-id qwen38-q8-local \
  --artifact-id qwen38-27b-q8_0 \
  --pid 12345 \
  --endpoint http://127.0.0.1:1200 \
  --backend-version e79e4bf \
  --context-size 16384

lmml runtime request \
  --lineage-id qwen38-27b \
  --purpose agentq-inference \
  --capability text-generation \
  --lease-id agentq-qwen38-001 \
  --json
```

Registration re-hashes the artifact and verifies that `/proc/<pid>/cmdline`
selects its exact path and declares the supplied context size exactly once. It
also records the canonical executable path, hashes the live executable through
`/proc/<pid>/exe`, and hashes the raw command line. Registration and lease
issuance require the endpoint's `/v1/models` response to identify that same
GGUF. Lease issuance rechecks the executable, command line, context, artifact,
and endpoint before returning an exact runtime-manifest hash. A lease returns
IDs, hashes, capabilities, and endpoint, not a filesystem path. Standard
llama.cpp advertises text generation only and returns an explicit unsupported
error for hidden-state or CROWN11 tap requests. An instrumented provider must
advertise and return real observations.

## Successor checkpoints

Before optimization, run the trainer in authorization-draft mode. This pass
re-hashes the canonical Qwen3.8 source, configures the real PEFT model,
enumerates every live trainable parameter, writes the proposed authorization,
and exits before constructing a `Trainer` or taking an optimizer step:

```sh
AUTH_ID=qwen38-successor-001-auth
RUN_ID=qwen38-successor-001-train
EVIDENCE=/workspace/lmml/outputs/lifecycle/$RUN_ID

MODEL_SOURCE_ROOT=/home/angelo/repos/qwen38-safetensors \
BASE_MANIFEST=/host-lmml/models/manifests/qwen38-27b.json \
AUTHORIZATION_DRAFT=$EVIDENCE/authorization-draft.json \
AUTHORIZATION_ID=$AUTH_ID \
SAVE_STRATEGY=no \
scripts/qlora-rocm-docker.sh train

lmml model authorize-successor-training \
  --base-manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --authorization outputs/lifecycle/$RUN_ID/authorization-draft.json \
  --json
```

The controlled training pass requires that immutable authorization. It rejects
intermediate checkpoint strategies and reused output directories, then compares
the canonical source, dataset, seed, package versions, full training config,
trainer/helper hashes, container image ID, ROCm device target, effective BLAS
backend, allowlist, and actual trainable inventory before `trainer.train()`.
After training, it requires finite loss and gradient norms, scans live LoRA
tensors, saves once, scans the serialized Safetensors payload, and writes the
schema-v2 `TrainingRunManifest` without replacement:

```sh
MODEL_SOURCE_ROOT=/home/angelo/repos/qwen38-safetensors \
BASE_MANIFEST=/host-lmml/models/manifests/qwen38-27b.json \
AUTHORIZATION_MANIFEST=/host-lmml/models/artifacts/adapters/authorizations/$AUTH_ID/authorization_manifest.json \
TRAINING_RUN_ID=$RUN_ID \
ADAPTER_ARTIFACT_ID=qwen38-successor-001-adapter \
TRAINING_REPORT=$EVIDENCE/training-run.json \
OUT_DIR=/workspace/lmml/outputs/qlora/$RUN_ID \
SAVE_STRATEGY=no \
scripts/qlora-rocm-docker.sh train
```

The wrapper records a host-visible adapter path in the report. Registering the
run makes LMML re-hash and finite-check that exact file against the immutable
authorization:

```sh
lmml model train-successor \
  --base-manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --authorization ~/.local/share/lmml/models/artifacts/adapters/authorizations/$AUTH_ID/authorization_manifest.json \
  --report outputs/lifecycle/$RUN_ID/training-run.json \
  --json
```

The draft and training commands load the model. Do not run them while the GPU is
reserved for another workload. `PYTHONPATH=scripts python3 -m unittest
scripts/test_qlora_lifecycle.py` exercises the identity and evidence helpers
without importing Torch or touching the GPU.

Merge only from the canonical unquantized parent. The training-side utility uses
the current Transformers `dtype=` API, writes a new candidate directory, measures
the LoRA delta, and compares live-adapter and merged logits:

```sh
python3 scripts/merge_lora.py \
  --base /home/angelo/repos/qwen38-safetensors \
  --adapter /models/adapters/adapter-1 \
  --output /models/successors/qwen38-successor-1 \
  --report merge-evidence.json \
  --dtype bfloat16 \
  --equivalence-inputs equivalence-inputs.json

lmml model merge-successor \
  --base-manifest ~/.local/share/lmml/models/manifests/qwen38-27b.json \
  --base-source /home/angelo/repos/qwen38-safetensors \
  --training-manifest training-run.json \
  --authorization authorization_manifest.json \
  --candidate /models/successors/qwen38-successor-1 \
  --successor-lineage-id qwen38-successor-1 \
  --candidate-id qwen38-successor-1-merge-1 \
  --report merge-evidence.json
```

LMML binds the merge report to the exact canonical base, adapter directory, and
candidate directory. It reproduces the pre-optimization authorization checks,
imports the candidate, requires the explicit parent, verifies all files, scans
every merged tensor for NaN or infinity, and checks architecture plus every
tensor name, dtype, and shape against the parent. It rejects zero deltas or
logit differences above the report tolerance. The merger and registrar also
reject overlapping base, adapter, candidate, and report paths, so successor
work cannot modify an input or add evidence files to the published checkpoint.
The candidate record stores the canonical training-manifest path and SHA-256,
plus the merge script path, script digest, Torch version, Transformers version,
PEFT version, and effective dtype evidence emitted by `merge_lora.py`.

Admission requires regression results for exactly the cases in the frozen parent
baseline. The report must name `parent_baseline_id` and include
`parent_baseline_hash`, the SHA-256 of the exact baseline manifest file:

```sh
sha256sum pristine-v1/manifest.json
```

```sh
lmml model admit-successor \
  --candidate-manifest candidate_manifest.json \
  --baseline-manifest pristine-v1/manifest.json \
  --report successor-admission.json
```

`successor-admission.json` carries the regression decision and copies the
identity fields that LMML checks against the immutable source records:

```json
{
  "schema_version": 2,
  "successor_lineage_id": "qwen38-successor-1",
  "parent_lineage_id": "qwen38-27b",
  "candidate_id": "qwen38-successor-1-merge-1",
  "training_run_id": "train-1",
  "training_manifest_hash": "<sha256>",
  "candidate_manifest_hash": "<sha256>",
  "adapter_artifact_id": "adapter-1",
  "dataset_hash": "<sha256>",
  "seed": 42,
  "training_config": {},
  "approved_allowlist": ["model.layers.*"],
  "trainable_parameters": ["model.layers.0.self_attn.q_proj.lora_A"],
  "requested_dtype": "bfloat16",
  "effective_load_dtype": "bfloat16",
  "merge_dtype": "bfloat16",
  "output_dtype": "bfloat16",
  "merge_tool": "/absolute/path/to/scripts/merge_lora.py",
  "merge_tool_version": "script_sha256=<sha256>;torch=<version>;transformers=<version>;peft=<version>",
  "tensor_manifest_hash": "<canonical-successor-hash>",
  "merge_delta": {
    "changed_tensor_count": 1,
    "unchanged_tensor_count": 0,
    "max_absolute_delta": 0.1,
    "aggregate_norm_delta": 1.0
  },
  "equivalence_max_absolute_delta": 0.000001,
  "equivalence_tolerance": 0.0001,
  "parent_baseline_id": "pristine-v1",
  "parent_baseline_hash": "<sha256>",
  "successor_hash": "<canonical-successor-hash>",
  "regression": [
    {
      "case_id": "anchor-1",
      "parent_metric": 1.0,
      "candidate_metric": 1.0,
      "delta": 0.0,
      "maximum_degradation": 0.1,
      "passed": true
    }
  ],
  "admitted_at": "2026-09-23T00:00:00Z"
}
```

Only this final command stores `successor_manifest.json` and the managed
successor substrate. LMML rejects a report bound to another baseline even when
its case names match. Admission re-reads and hashes the immutable training and
candidate manifests, then requires the final report to reproduce the dataset,
seed, training configuration, parameter allowlist and inventory, adapter ID,
dtype chain, merge-tool provenance, tensor-manifest hash, merge delta, and
logit-equivalence evidence. The final record therefore binds each copied field
to the exact source records instead of trusting a standalone admission report.
`model derive` refuses a successor lineage without that admission record.
Failed training, merge, equivalence, or regression leaves the parent untouched.

## Current gates

The code implements the substrate importer, immutable deterministic manifest,
verification path, identity separation, guarded GGUF derivation, append-only
artifact registration, quantized temporary publication, CPU-only container
conversion, artifact-bound runtime leases, deterministic baselines, and typed
successor gates.

The schema-v2 managed manifest now exists for the complete canonical checkpoint,
with canonical hash
`fe6a79f82e8c830c801ac5b82b0e18c19c0d6c1e5626534431b4424a8161e1d0`.
`llama-quantize` is built at managed llama.cpp revision `e79e4bf`. The host uses
an isolated converter layer with ROCm Torch 2.13, Safetensors 0.8, Transformers
5.14, NumPy 2.5, and llama.cpp's local GGUF module.

The first real CPU-side candidate set completed on 2026-08-26:

| Candidate | Bytes | SHA-256 |
|---|---:|---|
| BF16 | 54,657,735,808 | `cf3123616fbf0178a3abe3b58a438ca6d0e0088c19e0cafe57009408a496d86e` |
| Q8_0 | 29,047,086,208 | `f60d5f08ef1524a8aee53f02aa9c19d47b276524de004440dcb3c613bfafcb7a` |
| Q6_K | 22,431,001,728 | `15bba9deafd3454e5f48b7c2829e6715fa3c966d6297985ccb30444c675367ad` |
| Q4_K_M | 16,810,716,288 | `9d02bb6e73b840330600e6839f6dc32a1fb0df4c01665bdee567c7781717e9c8` |

Each manifest binds the candidate to canonical source hash
`fe6a79f82e8c830c801ac5b82b0e18c19c0d6c1e5626534431b4424a8161e1d0`
and llama.cpp revision `e79e4bf660e19f2ad851e06c6913f7a8c5852621`. Backend
admission and baseline execution remain paused under the operator's
no-model-start instruction. Admission now forces CPU-only loading, but no model
process has been started. No candidate is marked usable until metadata, tensor,
backend, hash, and lineage gates pass. No partial download is eligible for
conversion, and no Qwen3.5 asset is used as a fallback.

## Record examples

The canonical model identity and a Q8 deployment artifact remain separate:

```json
{
  "model": {
    "lineage_id": "qwen38-27b",
    "parent": null,
    "canonical_manifest_hash": "fe6a79f82e8c830c801ac5b82b0e18c19c0d6c1e5626534431b4424a8161e1d0"
  },
  "artifact": {
    "artifact_id": "qwen38-27b-q8_0",
    "model_lineage_id": "qwen38-27b",
    "representation": "gguf",
    "quantization": "q8_0",
    "artifact_hash": "<sha256-of-gguf>"
  }
}
```

The derivative chain records one canonical source anchor and independent GGUF
artifacts:

```text
qwen38-27b-safetensors
  -> qwen38-27b-f16
  -> qwen38-27b-q8_0
  -> qwen38-27b-q6_k
  -> qwen38-27b-q4_k_m
```

A lease returns the selected runtime and hashes, without returning the managed
artifact path:

```json
{
  "lease_id": "agentq-qwen38-001",
  "model_lineage_id": "qwen38-27b",
  "artifact_id": "qwen38-27b-q8_0",
  "runtime_id": "qwen38-q8-local",
  "runtime_manifest_hash": "<sha256-of-validated-runtime-manifest>",
  "endpoint": "http://127.0.0.1:1200",
  "manifest_hash": "fe6a79f82e8c830c801ac5b82b0e18c19c0d6c1e5626534431b4424a8161e1d0",
  "artifact_hash": "<sha256-of-gguf>",
  "capabilities": ["text_generation"]
}
```

Successor lineage remains explicit:

```text
qwen38-27b
  -> authorization-1
  -> training-run-1
  -> adapter-1
  -> candidate-1 (qwen38-successor-1, parent=qwen38-27b)
  -> successor admission
  -> admitted successor GGUF derivatives
```
