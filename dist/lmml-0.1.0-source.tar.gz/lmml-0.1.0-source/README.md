# lmml

<p align="center">
  <strong>🧭 Local Model Manager for llama.cpp</strong><br />
  Run local AI on the machines you already own.
</p>

<p align="center">
  <a href="LICENSE"><img alt="License: Apache-2.0" src="https://img.shields.io/badge/license-Apache--2.0-blue.svg" /></a>
  <img alt="Rust" src="https://img.shields.io/badge/Rust-local--AI-orange.svg" />
  <img alt="llama.cpp" src="https://img.shields.io/badge/runtime-llama.cpp-green.svg" />
  <img alt="LAN ready" src="https://img.shields.io/badge/LAN-router%20%2B%20workers-purple.svg" />
</p>

**Local AI should be easier to own, inspect, and route.**

`lmml` helps developers, researchers, and small teams run GGUF models with
`llama.cpp` without hand-assembling hardware probes, build flags, runtime
profiles, model paths, OpenAI-compatible endpoints, and LAN routing.

It is an open-source Rust toolkit from SoulHash for local model operations:
hardware detection, `llama.cpp` builds, GGUF model management, server lifecycle,
agent/client wiring, LAN node APIs, and a lightweight router for multiple idle
GPU machines.

> **One-line value proposition:** `lmml` helps local-AI builders deploy and
> coordinate `llama.cpp` inference without fragile shell glue by using a
> hardware-aware TUI, tested runtime profiles, OpenAI/Anthropic-compatible
> adapters, and opt-in LAN worker discovery.

```mermaid
flowchart LR
    Human["🧑‍💻 Human / Developer"] --> Client["🔌 Codex, OpenCode, Claude Code, scripts, agents"]
    Client --> API["🌐 OpenAI or Anthropic-compatible API"]
    API --> LMML["🧭 lmml"]
    LMML --> Llama["🦙 llama.cpp / llama-server"]
    Llama --> GPU["🖥️ Local GPU or LAN worker"]
```

## 🧩 The Challenge

You are building with local models because ownership, latency, cost control, and
inspectability matter. The hard part is not usually one command; it is keeping
the whole path dependable:

- choosing the right backend for CUDA, ROCm/HIP, Vulkan, Metal, Intel, or CPU;
- compiling a recent `llama.cpp` build with the right flags;
- matching GGUF models to VRAM, context, KV cache, draft heads, and chat format;
- exposing a safe local endpoint for tools such as Codex, OpenCode, Claude Code,
  Hermes-style clients, scripts, and agents;
- using idle LAN GPUs without turning every workstation into a manual snowflake.

The common failure mode is hidden complexity: stale binaries, wrong GPU arch
flags, broken model templates, context settings that exhaust VRAM, missing auth
on LAN routes, and agent clients pointed at the wrong endpoint.

## 🛠️ The Solution

SoulHash built `lmml` as the guide layer around `llama.cpp`.

`lmml` does not replace `llama.cpp`; it makes the operational path repeatable.
It detects the machine, builds or installs the runtime, tracks local GGUF files,
starts `llama-server`, exposes compatibility APIs, and can coordinate multiple
LAN workers through `lmml-node` and `lmml-router`.

The customer owns the mission: run useful local AI infrastructure with control.
`lmml` supplies the leverage: sane defaults, clear diagnostics, and tested
integration paths.

## ✨ Why It Matters

Local AI should not require surrendering ownership to a remote platform or
memorising every `llama-server` flag by hand. With `lmml`, you can move from
"I have a GPU and a model file" to "I have a working local endpoint for humans,
scripts, and agents" with fewer undocumented assumptions.

The practical value is simple:

- **Developers** get a local OpenAI-compatible server for coding agents and
  automation.
- **Researchers** get a repeatable way to test GGUF models and llama.cpp
  features on real hardware.
- **Small teams** get a LAN-first path for using idle workstation GPUs before
  buying more infrastructure.
- **Operators** get explicit security boundaries: localhost by default, bearer
  auth for LAN worker/router APIs, and opt-in discovery.

## ✅ Current Status

`lmml` is **open source** and in **active development**.

Implemented and tested today:

- Rust TUI binary: `lmml`.
- Worker API binary: `lmml-node`.
- LAN routing binary: `lmml-router`.
- Linux x86_64 LAN install/release flow for v0.1.0.
- Source-build bootstrap for development and host-specific builds.
- OpenAI-compatible `/v1/responses`, `/v1/chat/completions`, `/v1/embeddings`,
  and `/v1/models` pass-throughs.
- Anthropic `/v1/messages` compatibility endpoint through `lmml-node` and
  `lmml-router`.
- Model-family guidance for Qwen3.5, Qwen3.6, Gemma 4, and Hermes 4.
- Runtime profile support for validated Qwen, Gemma MTP, and BC-250 Vulkan
  scenarios.
- Side-by-side upstream and Prism runtimes with model-aware selection for
  Prism `PQ2_0`/`PTQ1_0` GGUF tensor formats.
- Simple TUI engine switching: press `v` on the Server tab to cycle
  `auto -> upstream -> prism`; press `p` to change the selected model's
  runtime profile.
- 262,144-token default server context with OpenCode model-limit publication
  and long-context compaction guidance.
- OCR profile support for Unlimited-OCR Q8 through `llama-mtmd-cli`.
- Opt-in LAN node discovery and authenticated router-to-worker probing.

Experimental or host-dependent:

- Native `llama.cpp` training workflows through `llama-finetune`.
- Gemma 4 MTP speculative decoding profiles, which require a matching draft
  model and recent `llama.cpp` support.
- Multimodal model operation, which requires the correct `mmproj` file and
  validated client routing.
- Non-Linux release artifacts until built and tested on matching hosts.

Not part of this project:

- No proprietary SoulHash or AgentQ engine code.
- No quantum technology claims or quantum-specific implementation.
- No bundled model weights.

## 🚀 Core Capabilities

**🧭 Hardware-aware setup:** Detects GPU, CPU, OS, compiler, and runtime tools so
you can build or install `llama.cpp` with fewer architecture mismatches.

**🖥️ TUI-driven local operations:** Gives humans a terminal interface to detect,
build, scan models, start/stop the server, inspect logs, and switch profiles.

**🧠 GGUF model management:** Scans local model directories, tracks aliases, reads
basic metadata, and maps known model families to safer runtime guidance.

**🔌 Agent-ready serving:** Runs local `llama-server` endpoints for Codex,
OpenCode, Claude Code, DeepSeek Harness, Hermes-style clients, shell scripts, and
OpenAI-compatible tools.

**💬 Anthropic compatibility:** Adds `/v1/messages` translation for clients that
speak Anthropic-style Messages APIs while your backend remains `llama.cpp`.

**🌐 LAN worker routing:** Lets one coordinator route requests across authenticated
`lmml-node` workers, including opt-in multicast discovery for idle GPU machines.

**⚙️ Runtime profiles:** Stores repeatable profile settings for context size,
parallelism, GPU layers, KV cache, draft-model flags, sampling, and server args.

**🧾 OCR profiles:** Runs image OCR through `llama-mtmd-cli` with a built-in
Unlimited-OCR Q8 profile and validated DeepSeek-OCR prompt flags.

**🧪 Training command support:** Wraps current upstream `llama-finetune` behavior
without pretending unsupported flags such as `--lora-out` exist unless the local
binary advertises them.

## 🧭 How It Works

1. **Start:** Install `lmml`, or build it from source.
2. **Activate:** Run the TUI, build/probe `llama.cpp`, scan GGUF models, and
   start a local server. On the Server tab, press `v` to choose the inference
   engine policy: `auto` selects Prism for PQ2/PTQ1 models and upstream
   llama.cpp for ordinary GGUF models.
3. **Advance:** Wire coding agents or LAN workers to the local endpoint, then
   route requests through `lmml-node` or `lmml-router` as your setup grows.

## ⚡ Quick Start

### Build From Source

```sh
git clone https://github.com/soulhash-labs/lmml.git
cd lmml
cargo build --release -p lmml-tui -p lmml-node -p lmml-router
./target/release/lmml doctor
./target/release/lmml
```

### Binary Or LAN Install

The release package includes `lmml`, `lmml-node`, `lmml-router`, `install.sh`,
`preflight.sh`, and `uninstall.sh`.

Serve the `dist/` directory from a trusted LAN release host:

```sh
cd dist
python3 -m http.server 8000
```

Install from another LAN machine:

```sh
curl -fsSL http://192.168.1.100:8000/install.sh | BASE_URL=http://192.168.1.100:8000 sh
```

Run after install:

```sh
lmml doctor
lmml
```

The LAN HTTP flow verifies `SHA256SUMS` for corruption detection. For untrusted
networks or public releases, require signed checksum verification:

```sh
curl -fsSL https://release.example/install.sh | \
  LMML_CHECKSUM_VERIFY=required \
  LMML_MINISIGN_PUBLIC_KEY='RW...' \
  sh
```

### Source-Build Bootstrap

Use source mode when the target machine must build `llama.cpp` locally, such as
ROCm/HIP, Vulkan-only, or unusual GPU hosts:

```sh
curl -fsSL http://192.168.1.100:8000/preflight.sh | LMML_INSTALL_MODE=source bash
curl -fsSL http://192.168.1.100:8000/install.sh | \
  BASE_URL=http://192.168.1.100:8000 \
  INSTALL_MODE=source \
  bash
```

For AMD ROCm/HIP nodes with a supported `rocminfo` `gfx*` target:

```sh
curl -fsSL http://192.168.1.100:8000/preflight.sh | \
  LMML_INSTALL_MODE=source \
  LMML_GPU_MODE=rocm \
  bash
curl -fsSL http://192.168.1.100:8000/install.sh | \
  BASE_URL=http://192.168.1.100:8000 \
  INSTALL_MODE=source \
  LMML_GPU_MODE=rocm \
  bash
```

For intentional CPU-only nodes:

```sh
curl -fsSL http://192.168.1.100:8000/preflight.sh | \
  LMML_INSTALL_MODE=source \
  LMML_GPU_MODE=cpu-only \
  bash
```

## 🔌 Agent And Client Wiring

### OpenCode

OpenCode is the first-class local coding harness target. LMML defaults to port
`8080`; the endpoint is configurable in TUI Settings and flows through every
model profile and runtime. Point OpenCode at the active OpenAI-compatible base
URL:

```text
baseURL: http://127.0.0.1:<lmml-port>/v1
model: llamacpp/<your-gguf-model-name>
```

After the LMML server reports `Status: Ready`, let LMML synchronize the active
model, endpoint, and OpenCode/Oh My OpenAgent routes:

```sh
lmml runtime configure opencode --dry-run --force
lmml runtime configure opencode --yes --force
```

The command verifies the live model before writing, preserves unrelated
settings, removes the fake `llamacpp_fast` route in single-server mode, and
creates timestamped backups. Restart OpenCode after synchronization.

LMML publishes the model limit to OpenCode as `context: 262144` and
`output: 16384`. A request cannot exceed 262,144 tokens. If an existing
OpenCode session has already grown beyond that limit, compact it or start a
new session; restarting the server does not shrink the old session history.

Quick verification (replace `<lmml-port>` with the port shown on LMML's Server
tab):

```sh
curl -fsS http://127.0.0.1:<lmml-port>/health
curl -fsS http://127.0.0.1:<lmml-port>/v1/models
opencode models llamacpp
```

### Codex CLI

Codex uses the OpenAI Responses API for custom model providers. Recent
`llama.cpp` exposes `/v1/responses`, and `lmml-node` / `lmml-router` pass that
route through to the managed `llama-server`.

Print a Codex profile snippet:

```sh
lmml runtime print-config codex
```

Add the reviewed TOML to `~/.codex/lmml.config.toml`, then start Codex with:

```sh
codex --profile lmml
```

### DeepSeek Harness

[DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness) can use
LMML as a local OpenAI-compatible provider. Start the selected LMML runtime,
then print the provider fragment:

```sh
lmml runtime print-config deepseek-harness
```

Review the output and add it under `$DSH_HOME/settings.yaml` (defaults to
`~/.dsh/settings.yaml`). The generated route uses `openai-completions`, points
to LMML's managed `/v1` endpoint, and names the selected model. DeepSeek Harness
remains an optional Node.js client; LMML does not bundle it or require it for
local serving.

For LAN routing, keep the same profile shape but set the provider `base_url` to
the router:

```toml
model_provider = "lmml"
model = "Qwen3.5-4B-Q8_0.gguf"

[model_providers.lmml]
name = "lmml LAN router"
base_url = "http://<router-ip>:8100/v1"
wire_api = "responses"
env_key = "LMML_ROUTER_API_KEY"
```

### Claude Code

Claude Code can use `lmml-node` through the Anthropic Messages compatibility
endpoint. Keep `llama-server` on port `8080`, then start the adapter:

```sh
LMML_NODE_API_KEY=local-dev-key lmml-node --llama-url http://127.0.0.1:8080
```

In the Claude Code shell:

```sh
export ANTHROPIC_BASE_URL=http://127.0.0.1:8101
export ANTHROPIC_AUTH_TOKEN=local-dev-key
export ANTHROPIC_MODEL=Qwen3.5-4B-Q8_0.gguf
export ANTHROPIC_SMALL_FAST_MODEL=Qwen3.5-4B-Q8_0.gguf
claude
```

Request path:

```text
Claude Code -> /v1/messages -> lmml-node -> llama-server /v1/chat/completions
```

### Hermes-Style Clients

Hermes-style OpenAI-compatible clients can target any `lmml` OpenAI-compatible
base URL:

```text
base URL: http://127.0.0.1:8080/v1
model: <your Hermes or other GGUF filename>
```

`lmml` also recognizes Hermes 4 GGUF names and displays family-specific guidance
where available. Recognition is not the same as a tuned runtime profile; keep
Hermes profiles explicit and hardware-validated.

## 🌐 LAN Routing And Idle Workstations

A LAN setup has two layers:

- `lmml-node`: exposes one machine as an authenticated worker API in front of a
  local `llama-server`.
- `lmml-router`: exposes one coordinator URL and routes requests across ready
  workers by route support, requested model, and current load metadata.

```mermaid
flowchart LR
    Client["🤖 Agents / IDEs / Scripts"] --> Router["🌐 lmml-router<br/>one LAN endpoint"]
    Router --> WS1["🖥️ lmml-node<br/>workstation GPU"]
    Router --> WS2["🎮 lmml-node<br/>idle gaming GPU"]
    Router --> BC250["🧱 lmml-node<br/>BC-250 Vulkan"]
    WS1 --> L1["🦙 llama-server"]
    WS2 --> L2["🦙 llama-server"]
    BC250 --> L3["🦙 llama-server"]
```

Static example:

```sh
# Worker beside a TUI-managed llama-server on port 8080.
LMML_NODE_API_KEY=worker-key lmml-node \
  --host 0.0.0.0 \
  --port 8101 \
  --node-name workstation \
  --llama-url http://127.0.0.1:8080

# Coordinator router.
LMML_ROUTER_API_KEY=router-key lmml-router \
  --host 0.0.0.0 \
  --port 8100 \
  --upstream workstation=http://192.168.1.101:8101 \
  --upstream-key workstation=worker-key
```

Point clients at the router:

```text
OpenAI-compatible base URL: http://<router-ip>:8100/v1
Anthropic-compatible base URL: http://<router-ip>:8100
```

Opt-in LAN discovery:

```sh
LMML_NODE_API_KEY=worker-key lmml-node \
  --host 0.0.0.0 \
  --port 8101 \
  --public-url http://192.168.1.101:8101 \
  --advertise-lan

LMML_ROUTER_API_KEY=router-key lmml-router \
  --host 0.0.0.0 \
  --port 8100 \
  --discover-lan \
  --upstream-key default=worker-key
```

Advertisements are hints, not trust. The router only uses a discovered worker
after authenticated health, capability, and load probes pass.

## 🧠 Model Family Guidance

`lmml` includes model-family guidance, not model weights.

### Qwen3.5 And Qwen3.6

Qwen profiles focus on long-context coding and agent workloads. `lmml` includes
safeguards for known Qwen runtime issues, including raw reasoning output when
needed, KV cache quantization guidance for large context, and profile-specific
context/parallelism settings.

Radeon AI PRO R9700 hosts get ROCm/HIP `gfx1201` profiles for Qwen3.5-style
9B Q8 models. `r9700-qwen9b-balanced2` uses `ctx_size=262144`, two server
slots, q8 KV cache, and full GPU layer auto-offload; `r9700-qwen9b-deep`
remains available for single-slot deep-context runs.

Supported catalog families include small Qwen variants and larger Qwen3.6
variants such as 27B and 35B-A3B-style MoE profiles where the hardware and GGUF
files are available.

### Qwen3.8 Native MTP

LMML includes Qwen3.8 27B profiles for GGUF files that contain the native 65th
NextN/MTP block. The profiles enable `draft-mtp` with up to three speculative
tokens and do not add a separate draft model:

```text
qwen38-27b-mtp-q4km: Qwen3.8-27B-ABLITERATED-Q4_K_M.gguf, ctx 16384
qwen38-27b-mtp-q6:   Qwen3.8-27B-ABLITERATED-Q6_K.gguf, ctx 16384
qwen38-27b-mtp-q8:   Qwen3.8-27B-ABLITERATED-Q8_0.gguf, ctx 16384
args: --spec-type draft-mtp --spec-draft-n-max 3 --jinja -fa on
```

The ABLITERATED GGUF files are provided by [Blackfrost-AI on Hugging Face](https://huggingface.co/Blackfrost-AI/Qwen3.8-27B-ABLITERATED-GGUF).
LMML does not bundle or redistribute the model weights; download them under
the repository's license and place the selected GGUF in the configured models
directory.

Special thanks to Hatsu | Ai for recommending Blackfrost-AI's Qwen3.8 build for
cybersecurity work.

Use a current llama.cpp build that recognizes the model's 65-layer metadata.
The profile is for text serving; omit `--mmproj` unless the selected GGUF
release provides and documents a compatible projector. For manually converted
safetensors, convert to a GGUF that preserves the embedded MTP block before
selecting the LMML profile.

### Gemma 4

Gemma 4 support includes QAT-oriented guidance and an MTP profile for speculative
decoding when a matching draft head is available:

```text
gemma4-12b-mtp-q4km:
  model: Gemma4-12B-QAT-Q4_K_M.gguf
  draft: mtp-gemma-4-12B-it.gguf
  args: -md <draft> --spec-type draft-mtp -fa on
  sampling: temperature=0.6 top_k=64 top_p=0.9 min_p=0.05 repeat_penalty=1.1
```

### BC-250 Vulkan Nodes

Headless AMD BC-250 machines can run as LAN workers with source-built Vulkan
support:

```sh
curl -fsSL http://192.168.1.100:8000/install.sh | \
  BASE_URL=http://192.168.1.100:8000 \
  INSTALL_MODE=source \
  LMML_GPU_MODE=vulkan \
  LMML_PROFILE_HINT=bc250-qwen35-9b-q4km-vulkan \
  sh
```

### Unlimited-OCR Q8

Unlimited-OCR uses llama.cpp's multimodal CLI path, not the normal
`llama-server` request path. LMML exposes it through the built-in OCR profile
`unlimited-ocr-q8-mtmd`.

Use these two files:

```text
~/.local/share/lmml/models/unlimited-ocr-Q8_0.gguf
~/.local/share/lmml/models/mmproj-unlimited-ocr-F16.gguf
```

GGUF model files are published at
<https://huggingface.co/vimalnakrani/unlimited-ocr-gguf>.

Run OCR on an image:

```sh
lmml ocr \
  --model ~/.local/share/lmml/models/unlimited-ocr-Q8_0.gguf \
  --image ./page.png
```

If `unlimited-ocr-Q8_0.gguf` is already selected in the TUI, omit `--model`:

```sh
lmml ocr --image ./page.png
```

The profile emits the measured llama.cpp flag set, adding `--no-warmup` when
the installed `llama-mtmd-cli` advertises it:

```text
-m unlimited-ocr-Q8_0.gguf
--mmproj mmproj-unlimited-ocr-F16.gguf
--image page.png
-p "document parsing."
--chat-template deepseek-ocr
--temp 0
--repeat-penalty 1.0
--flash-attn off
-n 2600
-c 16384
--no-warmup
```

Override a profile value for one run:

```sh
lmml ocr \
  --model ~/.local/share/lmml/models/unlimited-ocr-Q8_0.gguf \
  --image ./invoice.png \
  --prompt "document parsing." \
  -c 16384 \
  -n 2600
```

Use `--mmproj` if the projector is not beside the language GGUF. Pass extra
`llama-mtmd-cli` flags after `--`.

LMML does not expose Unlimited-OCR as a server runtime profile yet. Current
llama.cpp builds can host the model in `llama-server`, but the image prompt path
for this architecture is validated through `llama-mtmd-cli`.

## 🧪 Native llama.cpp Training

`lmml train` is an experimental wrapper around native `llama.cpp` training
binaries. It does not run a Python/PyTorch fine-tuning stack.

Current upstream `llama-finetune` behavior is treated as full-model GGUF
fine-tuning. `lmml` maps common intent flags to the local binary’s advertised
capabilities and only enables custom-fork flags such as `--lora-out` when
`llama-finetune --help` explicitly reports support.

Example:

```sh
lmml train \
  --model-base ./models/Qwen3.5-9B-BF16.gguf \
  --train-data ./data/train.txt \
  --output ./models/Qwen3.5-9B-Finetuned.gguf \
  -- --epochs 3 --ctx-size 512 --batch-size 4 --n-gpu-layers 32
```

Use F16/BF16 bases for training and quantize the output GGUF afterward.

## 🏗️ Architecture

```mermaid
flowchart TB
    TUI["🧭 lmml TUI"]
    Detect["🔎 hardware detection"]
    Build["🛠️ llama.cpp build/install"]
    Models["🧠 GGUF scan + profiles"]
    Server["🦙 llama-server lifecycle"]
    Node["🔐 lmml-node worker API"]
    Router["🌐 lmml-router coordinator"]
    Clients["🤖 OpenCode / Claude Code / Hermes / scripts"]

    TUI --> Detect --> Build --> Models --> Server
    Server --> Node
    Node --> Router
    Clients --> Router
    Clients --> Server
```

Workspace crates:

- `lmml-api` — shared API DTOs and version constants.
- `lmml-build` — `llama.cpp` clone/configure/build pipeline.
- `lmml-compat` — `llama-server` flag compatibility probing.
- `lmml-detect` — hardware and toolchain detection.
- `lmml-models` — GGUF scanning, aliases, and model catalog guidance.
- `lmml-node` — worker API in front of a local `llama-server`.
- `lmml-router` — LAN coordinator and load router.
- `lmml-server` — local server lifecycle management.
- `lmml-state` — config/state/runtime profile persistence.
- `lmml-tui` — terminal UI and CLI entrypoint.

## 📚 Documentation

- [How to use lmml](docs/how-to-use.md)
- [LAN client install guide](docs/lan-client-install.md)
- [Training guide](docs/training-how-to-use.md)
- [ROCm QLoRA adapter training](docs/qlora-rocm-training.md)
- [GPU support catalog](docs/hardware-gpu-support.md)
- [LLM model support catalog](docs/llm-model-support.md)
- [Fleet profile reference](docs/lmml-fleet-profiles.md)
- [Runtime harness plan](docs/runtime-harness-plan.md)
- [Release checklist](docs/release-checklist.md)
- [Integration contract](docs/lmml-integration-contract.md)

## 🧑‍💻 Development

Prerequisites:

```sh
rustup update stable
```

Common commands:

```sh
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace -- -D warnings
cargo build --release -p lmml-tui -p lmml-node -p lmml-router
```

Package a release:

```sh
scripts/package-release.sh
```

Run the TUI from source:

```sh
cargo run -p lmml-tui
```

## 🔐 Security Model

- Localhost is the default serving posture.
- LAN binds require bearer auth unless an explicit unsafe development escape
  hatch is used.
- `lmml-node` and `lmml-router` require authenticated non-health routes.
- LAN discovery is opt-in and advertisements are verified before routing.
- LAN HTTP installer checksums detect corrupt downloads; signed checksum
  verification is required for untrusted distribution.
- Model weights are not bundled.

Please do not report private credentials in public issues. If this repository
adds a dedicated security contact, use that path for sensitive reports.

## 🤝 Contributing

Contributions are useful when they improve a tested path:

- hardware probe fixtures for more GPUs and drivers;
- runtime profiles with clear model, quant, context, and VRAM evidence;
- compatibility tests for `llama.cpp` flag changes;
- docs that separate validated behavior from planned behavior;
- LAN routing and agent-client integration tests.

Before opening a pull request, run:

```sh
cargo fmt --all -- --check
cargo test --workspace
cargo clippy --workspace -- -D warnings
```

## 📄 License

Apache-2.0. See [LICENSE](LICENSE).

## ⭐ Call To Action

Clone the repository, run `lmml doctor`, and try the TUI against one local GGUF
model. If it helps you turn an idle GPU into a dependable local-AI endpoint,
star the repo and contribute the hardware/profile evidence back.

**Purpose:** `lmml` exists so advanced local AI remains open, inspectable, and
controlled by the people running it.
